/*
"use client"

// components/PurchasesList.tsx
import React, {useEffect, useState} from "react";
import Image from "next/image";
import { getAllUsersPurchases } from "@/services/api/usersService";
import { Purchase } from "@/shared/types/user";
import {usePurchasesQuery} from "@/shared/hooks/usePurchasesQuery";

// Ця компонента – серверна, тому вона може бути async
export default function PurchasesList() {
    // Отримуємо дані прямо на сервері
    const purchases = usePurchasesQuery();
    //const purchases: Purchase[] = await getAllUsersPurchases();
    const [isMounted, setIsMounted] = useState(false);


    useEffect(() => {
        setIsMounted(true);
    }, []);

    if (!isMounted) {
        return null;
    }
    return (
        <div className="grid grid-cols-5 gap-4">
            {purchases.data?.map((purchase) => (
                <div key={purchase.id} className="border p-2">
                    <Image
                        alt={purchase.name}
                        src={purchase.img  || ""} // API повинно повертати img як URL
                        width={123}
                        height={124}

                        loading={"eager"}
                    />
                    <div className="mt-2 text-sm">
                        <p className="font-semibold">{purchase.name}</p>
                        <p className="text-gray-500">User ID: {purchase.userId}</p>
                        <p className="text-gray-400 text-xs">{purchase.date}</p>
                    </div>
                </div>
            ))}
        </div>
    );
}
*/
/*


// purchases/components/PurchasesList.tsx (СЕРВЕРНА КОМПОНЕНТА, без use client!)
import React from "react";
import Image from "next/image";
import { getAllUsersPurchases } from "@/services/api/usersService";
import { Purchase } from "@/shared/types/user";

export default async function PurchasesList() {
    const purchases: Purchase[] = await getAllUsersPurchases();

    return (
        <div className="grid grid-cols-5 gap-4">
            {purchases.map((purchase) => (
                <div key={purchase.id} className="border p-2">
                    <Image
                        alt={purchase.name}
                        src={purchase.img || ""}
                        width={123}
                        height={124}
                        // У Next Image в 13-й версії лентиве завантаження і так за замовчуванням,
                        // але якщо хочете явно, то можна вказати loading="lazy"
                        loading="lazy"
                    />
                    <div className="mt-2 text-sm">
                        <p className="font-semibold">{purchase.name}</p>
                        <p className="text-gray-500">User ID: {purchase.userId}</p>
                        <p className="text-gray-400 text-xs">{purchase.date}</p>
                    </div>
                </div>
            ))}
        </div>
    );
}
*/



"use client";
import React from "react";
import Image from "next/image";
import { usePurchasesQuery } from "@/shared/hooks/usePurchasesQuery";
import {purchases} from "@/shared/constants";
export default function PurchasesList() {

   // const { data: purchases, isLoading } = usePurchasesQuery();
   // if (isLoading) return <div>Loading...</div>;
    return (
        <div className="grid grid-cols-5 gap-4">
            {purchases?.map((purchase) => (
                <div key={purchase.id} className="border p-2">
                    <Image
                        alt={purchase.name}
                        src={purchase.img || ""}
                        width={123}
                        height={124}
                        loading="lazy"
                    />
                    <div className="mt-2 text-sm">
                        <p className="font-semibold">{purchase.name}</p>
                        <p className="text-gray-500">User ID: {purchase.userId}</p>
                        <p className="text-gray-400 text-xs">{purchase.date}</p>
                    </div>
                </div>
            ))}
        </div>
    );
}



