"use client";
import React, {useState} from "react";
import dynamic from "next/dynamic";
//import DynamicModalContent from "./ModalContent"
const DynamicModalContent = dynamic(() => import("./ModalContent"), {
    loading: () => <p>Loading...</p>,
});

export default function PurchasesModal() {
    const [open, setOpen] = useState(false);
    const handleOpenModal = () => setOpen(true);
    const handleCloseModal = () => setOpen(false);
    return (
        <div>
            <button
                className="mb-4 p-2 bg-purple-500 text-white rounded"
                onClick={handleOpenModal}
            >
                Open Modal (lazy-load)
            </button>
            {open && (
                <DynamicModalContent onClose={handleCloseModal}/>
            )}
        </div>
    );
}



