"use client";
import React from "react";
import PurchasesList from "@/features/purchases/components/PurchasesList";

export default function ModalContent({ onClose }: { onClose: () => void }) {
    return (
        <div className="fixed top-[50px] left-1/2 -translate-x-1/2 p-5 border border-black bg-white z-[9999]">
            <h2 className="text-xl font-semibold">Heavy Modal Content</h2>
            <p className="mt-2">This content is loaded “lazily” with dynamic import</p>
            <button onClick={onClose} className="text-blue-400 cursor-pointer mt-4">Close Modal</button>
            <div className="mt-5 overflow-y-auto max-h-[60vh]">
                <PurchasesList/>
            </div>
        </div>
    );
}


