import { User } from "@/shared/types/user";
import UsersListClient from "@/features/users/components/clients/UsersListClient";


const UsersListServer = async () => {
    const res = await fetch("http://localhost:3001/api/users");
    const users: User[] = await res.json();

    return <UsersListClient initialUsers={users} />;
};

export default UsersListServer;





