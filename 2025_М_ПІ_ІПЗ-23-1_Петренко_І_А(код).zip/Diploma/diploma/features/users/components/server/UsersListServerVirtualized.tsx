import { dehydrate, HydrationBoundary, QueryClient } from "@tanstack/react-query";
import UsersListClientVirtualized from "@/features/users/components/clients/UsersListClientVirtualized";

const fetchUsers = async () => {
    const res = await fetch("http://localhost:3001/api/users");
    return res.json();
};

const UsersListServerVirualized = async () => {
    const queryClient = new QueryClient();
    await queryClient.prefetchQuery({ queryKey: ["users"], queryFn: fetchUsers });

    return (
        <HydrationBoundary state={dehydrate(queryClient)}>
            <UsersListClientVirtualized />
        </HydrationBoundary>
    );
};

export default UsersListServerVirualized;
