import { dehydrate, HydrationBoundary, QueryClient } from "@tanstack/react-query";
import UsersListClient from "@/features/users/components/clients/UsersListClient";
import UsersListClientTanstack from "@/features/users/components/clients/UsersListClientTanstack";

const fetchUsers = async () => {
    const res = await fetch("http://localhost:3001/api/users");
    return res.json();
};

const UsersListServerTanstack = async () => {
    const queryClient = new QueryClient();
    await queryClient.prefetchQuery({ queryKey: ["users"], queryFn: fetchUsers });

    return (
        <HydrationBoundary state={dehydrate(queryClient)}>
            <UsersListClientTanstack />
        </HydrationBoundary>
    );
};

export default UsersListServerTanstack;




