"use client";
import { useQuery } from "@tanstack/react-query";
import React, { useMemo, useState, useCallback, memo } from "react";
import { FixedSizeGrid as Grid } from "react-window";
import UserCard from "@/features/users/components/UserCard";
import { useRouter } from 'next/navigation'
import PurchasesModal from "@/features/purchases/components/PurchasesModal";

const fetchUsers = async () => {
    const res = await fetch("http://localhost:3001/api/users");
    if (!res.ok) throw new Error("Failed to fetch users");
    return res.json();
};

const MemoizedUserCard = memo(UserCard);
const COLUMN_COUNT = 5;
const CARD_WIDTH = 335;
const CARD_HEIGHT = 480;
const VirtualizedUsersGrid = () => {
    const { data: users = [], isLoading, error } = useQuery({ queryKey: ["users"], queryFn: fetchUsers });
    const [sortBy, setSortBy] = useState<"age" | "firstName">("age");
    const [search, setSearch] = useState("");
    const router = useRouter();

    const handleUsersPurchasesClick = () => {
        router.push("/users-purchases")
    }
    const handleSearchChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
        setSearch(e.target.value);
    }, []);
    const sortedUsers = useMemo(() => {
        return [...users]
            .filter((user) => user.firstName.toLowerCase().includes(search.toLowerCase()))
            .sort((a, b) => (sortBy === "age" ? a.age - b.age : a.firstName.localeCompare(b.firstName)));
    }, [users, search, sortBy]);
    const handleUserClick = useCallback((id: number) => {
        router.replace(`/${id}`);
    }, []);
    if (isLoading) return <p>Loading...</p>;
    if (error) return <p>Error: {error.message}</p>;
    const rowCount = Math.ceil(sortedUsers.length / COLUMN_COUNT);
    const Cell = ({ columnIndex, rowIndex, style }: any) => {
        const index = rowIndex * COLUMN_COUNT + columnIndex;
        const user = sortedUsers[index];
        if (!user) return null;
        return (
            <div style={style} className="p-2">
                <MemoizedUserCard
                    user={user}
                    onClick={handleUserClick}
                />
            </div>
        );
    };
    return (
        <div className="p-3 bg-blue-200">
            <button onClick={handleUsersPurchasesClick} className="my-3 text-purple underline cursor-pointer">Users
                purchases
            </button>
            <input
                type="text"
                placeholder="search for name"
                value={search}
                onChange={handleSearchChange}
                className="p-2 mb-4 w-full border rounded"
            />
            <div className="flex items-center gap-5">
                <button
                    onClick={() => setSortBy(sortBy === "age" ? "firstName" : "age")}
                    className="mb-4 p-2 bg-blue-500 text-white rounded"
                >
                    Sort by {sortBy === "age" ? "name" : "age"}
                </button>
                <div>
                    <PurchasesModal/>
                </div>
            </div>
            <Grid
                columnCount={COLUMN_COUNT}
                columnWidth={CARD_WIDTH - 10}
                height={794}
                rowCount={rowCount}
                rowHeight={CARD_HEIGHT}
                width={CARD_WIDTH * COLUMN_COUNT}
            >
                {Cell}
            </Grid>
        </div>
    );
};

export default VirtualizedUsersGrid;
