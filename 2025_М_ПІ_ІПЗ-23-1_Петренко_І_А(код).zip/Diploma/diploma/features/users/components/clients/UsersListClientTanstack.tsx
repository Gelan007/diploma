"use client";
import {useQuery} from "@tanstack/react-query";
import React, {useMemo, useState, useCallback} from "react";
import UserCard from "@/features/users/components/UserCard";
import {memo} from "react";
import {useRouter} from "next/navigation";
import PurchasesModal from "@/features/purchases/components/PurchasesModal";

const fetchUsers = async () => {
    const res = await fetch("http://localhost:3001/api/users");
    if (!res.ok) throw new Error("Failed to fetch users");
    return res.json();
};
const MemoizedUserCard = memo(UserCard);
const UsersListClientTanstack = () => {
    const {data: users = [], isLoading, error} = useQuery({queryKey: ["users"], queryFn: fetchUsers});
    const [sortBy, setSortBy] = useState<"age" | "firstName">("age");
    const [search, setSearch] = useState("");
    const router = useRouter();
    const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setSearch(e.target.value);
    };

    const sortedUsers = useMemo(() => {
        return [...users]
            .filter((user) => user.firstName.toLowerCase().includes(search.toLowerCase()))
            .sort((a, b) => (sortBy === "age" ? a.age - b.age : a.firstName.localeCompare(b.firstName)));
    }, [users, search, sortBy]);

    const handleUserClick = useCallback((id: number) => {
        router.replace(`/${id}`);
    }, []);

    if (isLoading) return <p>Loading...</p>;
    if (error) return <p>Error: {error.message}</p>;

    return (
        <div className="p-3 bg-blue-200">
            <input
                type="text"
                placeholder="Пошук за ім'ям..."
                value={search}
                onChange={handleSearchChange}
                className="p-2 mb-4 w-full border rounded"
            />
            <div className="flex items-center gap-5">
                <button
                    onClick={() => setSortBy(sortBy === "age" ? "firstName" : "age")}
                    className="mb-4 p-2 bg-blue-500 text-white rounded"
                >
                    Sort by {sortBy === "age" ? "name" : "age"}
                </button>
                <div>
                    <PurchasesModal/>
                </div>
            </div>
            <div className="grid grid-cols-5 gap-4">
                {sortedUsers.map((user) => (
                    <MemoizedUserCard onClick={handleUserClick} user={user} key={user.id}/>
                ))}
            </div>
        </div>
    );
};

export default UsersListClientTanstack;
