import React from 'react';
import {User} from "@/shared/types/user";
import Image from "next/image";
import UserImage from "@/assets/images/user.png"

type UserCardProps = {
    user: User;
    onClick: (id: number) => void;
    className?: string;
}
const UserCard: React.FC<UserCardProps> = React.memo(({user, onClick, className}) => {
    return (
        <div className={`flex flex-col bg-white rounded-lg shadow-sm p-3 ${className}`} onClick={() => onClick(user.id)}>
            <Image src={UserImage} alt="user"/>
            <span className="text-lg text-black font-bold">{`${user.firstName} ${user.lastName}`}</span>
            <span className="text-base text-grey font-semibold">age: {`${user.age}`}</span>
            <span className="text-base text-grey font-semibold">phone: {`${user.phone}`}</span>
            <span className="text-base text-grey font-semibold">email: {`${user.email}`}</span>
            <span className="text-base text-grey font-semibold">city: {`${user.city}`}</span>
            <span className="text-base text-grey font-semibold">country: {`${user.country}`}</span>
        </div>
    );
});

export default UserCard;