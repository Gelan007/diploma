export const getUsers = async () => {
    const res = await fetch("http://localhost:3001/api/users");
    if (!res.ok) throw new Error("Failed to fetch users");
    return res.json();
};

export const getAllUsersPurchases = async () => {
    const res = await fetch("http://localhost:3001/api/users/purchases");
    if (!res.ok) throw new Error("Failed to fetch purchases");
    return res.json();
};