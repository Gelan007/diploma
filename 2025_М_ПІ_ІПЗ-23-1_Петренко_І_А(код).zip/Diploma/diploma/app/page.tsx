import Image from "next/image";
import {User} from "@/shared/types/user";
import UserCard from "@/features/users/components/UserCard";
import UsersListServer from "@/features/users/components/server/UsersListServer";
import UsersListServerTanstack from "@/features/users/components/server/UsersListServerTanstack";
import UsersListServerVirtualized from "@/features/users/components/server/UsersListServerVirtualized";
import UsersListVirtualized from "@/features/users/components/clients/UsersListClientVirtualized";
import UsersListClient from "@/features/users/components/clients/UsersListClient";




export default function Home() {



    return (
        <div>

            {/*<UsersListServer />*/}
            {/*<UsersListServerTanstack />*/}
             {/*<UsersListServerVirtualized />*/}
            <UsersListServerVirtualized />

        </div>
    )
}
