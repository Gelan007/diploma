// app/users/[id]/page.tsx
import {use} from "react";
import {GoBackButton} from "@/shared/components/GoBackButton";

interface PageProps {
    params: { id: string }
}

export default async function UserDetailsPage({ params }: PageProps) {
    //const res = await fetch(`http://localhost:3001/api/users/${params.id}`);
    //const user = await res.json();

    //if (!user) return <div>User not found</div>;

    return (
        <div className="p-4">
            <GoBackButton/>
            <h1 className="text-xl font-bold mb-2">User Details</h1>
            {params.id}
            {/*<p><strong>ID:</strong> {user.id}</p>*/}
            {/*<p><strong>First Name:</strong> {user.firstName}</p>*/}
            {/*<p>Age: {user.age}</p>*/}
            {/* Додай більше інформації, якщо потрібно */}
        </div>
    );
}
