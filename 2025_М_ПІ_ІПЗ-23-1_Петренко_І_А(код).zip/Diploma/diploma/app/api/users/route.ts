// // import {connectToDB} from "@utils/database";
// // import Expense from "@models/expense";
// // import {IExpense} from "@interfaces/expense";
// // import {NextResponse} from "@node_modules/next/dist/diploma-server/web/spec-extension/response";
//
// // export const POST = async (req: Request , res: Response) => {
// //     try {
// //         const { description, amount, date }: IExpense = await req.json();
// //
// //         await connectToDB();
// //
// //         const newExpense = new Expense({
// //             description,
// //             amount,
// //             date: new Date(date)
// //         });
// //
// //         await newExpense.save();
// //
// //         return new Response(JSON.stringify(newExpense), { status: 201 });
// //     } catch (err) {
// //         return new Response("Failed to create a new expense", { status: 500 });
// //     }
// //
// // }
// //
// // export const GET = async (req: Request , res: Response) => {
// //     try {
// //         await connectToDB();
// //
// //         const expenses = await Expense.find({});
// //         return new Response(JSON.stringify(expenses), {status: 200})
// //     } catch(err) {
// //         return new Response("Failed to fetch all expenses", {status: 500});
// //     }
// // }
//
//
// import { NextRequest, NextResponse } from 'next/diploma-server';
//
// export async function GET(req: NextRequest) {
//     try {
//         // Массив с данными пользователей
//         const usersService.ts = [
//             {
//                 id: 1,
//                 firstName: 'John',
//                 lastName: 'Doe',
//                 age: 25,
//                 email: 'john.doe@example.com',
//                 phone: '+1-555-0101',
//                 country: 'USA',
//                 city: 'New York'
//             },
//             {
//                 id: 2,
//                 firstName: 'Jane',
//                 lastName: 'Smith',
//                 age: 30,
//                 email: 'jane.smith@example.com',
//                 phone: '+1-555-0102',
//                 country: 'Canada',
//                 city: 'Toronto'
//             },
//             {
//                 id: 3,
//                 firstName: 'Michael',
//                 lastName: 'Brown',
//                 age: 22,
//                 email: 'michael.brown@example.com',
//                 phone: '+44-555-0103',
//                 country: 'UK',
//                 city: 'London'
//             }
//         ];
//
//         // Возвращаем ответ с пользователями
//         return NextResponse.json(usersService.ts, { status: 200 });
//     } catch (error) {
//         console.error('Error fetching usersService.ts:', error);
//         return NextResponse.json({ message: 'Failed to fetch usersService.ts' }, { status: 500 });
//     }
// }