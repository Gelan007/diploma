import {GoBackButton} from "@/shared/components/GoBackButton";
import PurchasesModal from "@/features/purchases/components/PurchasesModal";

export default function UsersPurchasesPage() {
    return (
        <div className="p-3 bg-blue-200 min-h-screen ">
            <h1 className="text-2xl font-bold mb-4">Users Last Purchases</h1>
            <GoBackButton/>

            <div className="mb-3">
                <PurchasesModal/>
            </div>
        </div>
    );
}



