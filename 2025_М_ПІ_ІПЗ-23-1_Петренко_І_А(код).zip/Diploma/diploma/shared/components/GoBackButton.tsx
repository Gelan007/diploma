"use client"
import {useRouter} from "next/navigation";

export function GoBackButton() {
    const router = useRouter();
    return (
        <button
            onClick={() => router.push("/")}
            className="flex items-center text-sm text-blue-600 hover:underline mb-4"
        >
            Back
        </button>
    );
}