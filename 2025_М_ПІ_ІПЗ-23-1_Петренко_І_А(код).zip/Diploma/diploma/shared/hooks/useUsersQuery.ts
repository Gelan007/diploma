import { useQuery } from "@tanstack/react-query";
import {getUsers} from "@/services/api/usersService";


export function useUsersQuery() {
    return useQuery({
        queryKey: ["users"],
        queryFn: getUsers,
    });
}