import { useQuery } from "@tanstack/react-query";
import {Purchase} from "@/shared/types/user";
import {getAllUsersPurchases} from "@/services/api/usersService";

const images = [
    "/assets/images/iphone1.png",
    "/assets/images/iphone2.png",
    "/assets/images/iphone3.png",
    "/assets/images/iphone4.png",
    "/assets/images/iphone5.png",
    "/assets/images/iphone6.png",
    "/assets/images/iphone7.png",
];

export function usePurchasesQuery() {
    return useQuery({
        queryKey: ["purchases"],
        queryFn: async () => {
            const data: Purchase[] = await getAllUsersPurchases();
            /*return data.map((item, index) => ({
                ...item,
                img: images[index % images.length],
            }));*/
            return data;
        },
    });
}
