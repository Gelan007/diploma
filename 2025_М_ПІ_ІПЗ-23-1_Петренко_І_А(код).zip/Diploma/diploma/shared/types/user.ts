import {ReactNode} from "react";

export interface User {
    id: number;
    email: string;
    age: number;
    firstName: string;
    lastName: string;
    phone: string;
    country: string;
    city: string;
    purchases?: Purchase[];
}

export interface Purchase {
    userId: number;
    id: string;
    name: string;
    date: string;
    img: string;
}