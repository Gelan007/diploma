(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_b8452c29._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_b8452c29._.js",
  "chunks": [
    "static/chunks/node_modules_7c0e7d69._.js",
    "static/chunks/_ee652fa1._.js"
  ],
  "source": "dynamic"
});
