(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_tsx_aaf7d535._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_tsx_aaf7d535._.js",
  "chunks": [
    "static/chunks/[root of the server]__772746f6._.css",
    "static/chunks/_3c62805b._.js"
  ],
  "source": "dynamic"
});
