(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_[id]_page_tsx_1781884c._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_[id]_page_tsx_1781884c._.js",
  "chunks": [
    "static/chunks/_70dc233c._.js"
  ],
  "source": "dynamic"
});
