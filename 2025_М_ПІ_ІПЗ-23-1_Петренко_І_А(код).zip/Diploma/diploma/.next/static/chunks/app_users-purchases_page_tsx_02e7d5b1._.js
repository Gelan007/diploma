(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_users-purchases_page_tsx_02e7d5b1._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_users-purchases_page_tsx_02e7d5b1._.js",
  "chunks": [
    "static/chunks/features_purchases_components_ModalContent_tsx_b086880d._.js",
    "static/chunks/_c1f67c07._.js"
  ],
  "source": "dynamic"
});
