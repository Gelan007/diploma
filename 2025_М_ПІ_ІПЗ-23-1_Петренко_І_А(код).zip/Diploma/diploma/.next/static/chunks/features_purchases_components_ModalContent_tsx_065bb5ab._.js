(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/features_purchases_components_ModalContent_tsx_065bb5ab._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/features_purchases_components_ModalContent_tsx_065bb5ab._.js",
  "chunks": [
    "static/chunks/_c6f6cd2b._.js"
  ],
  "source": "dynamic"
});
