(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/_de8e4f01._.js", {

"[project]/shared/components/GoBackButton.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, d: __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "GoBackButton": (()=>GoBackButton)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
function GoBackButton() {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        onClick: ()=>router.back(),
        className: "flex items-center text-sm text-blue-600 hover:underline mb-4",
        children: "Back"
    }, void 0, false, {
        fileName: "[project]/shared/components/GoBackButton.tsx",
        lineNumber: 7,
        columnNumber: 9
    }, this);
}
_s(GoBackButton, "fN7XvhJ+p5oE6+Xlo0NJmXpxjC8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = GoBackButton;
var _c;
__turbopack_context__.k.register(_c, "GoBackButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/services/api/usersService.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, d: __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "getAllUsersPurchases": (()=>getAllUsersPurchases),
    "getUsers": (()=>getUsers)
});
const getUsers = async ()=>{
    const res = await fetch("http://localhost:3001/api/users");
    if (!res.ok) throw new Error("Failed to fetch users");
    return res.json();
};
const getAllUsersPurchases = async ()=>{
    const res = await fetch("http://localhost:3001/api/users/purchases");
    if (!res.ok) throw new Error("Failed to fetch purchases");
    return res.json();
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/shared/hooks/usePurchasesQuery.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, d: __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "usePurchasesQuery": (()=>usePurchasesQuery)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$api$2f$usersService$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/services/api/usersService.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
const images = [
    "/assets/images/iphone1.png",
    "/assets/images/iphone2.png",
    "/assets/images/iphone3.png",
    "/assets/images/iphone4.png",
    "/assets/images/iphone5.png",
    "/assets/images/iphone6.png",
    "/assets/images/iphone7.png"
];
function usePurchasesQuery() {
    _s();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])({
        queryKey: [
            "purchases"
        ],
        queryFn: {
            "usePurchasesQuery.useQuery": async ()=>{
                const data = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$api$2f$usersService$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAllUsersPurchases"])();
                /*return data.map((item, index) => ({
                ...item,
                img: images[index % images.length],
            }));*/ return data;
            }
        }["usePurchasesQuery.useQuery"]
    });
}
_s(usePurchasesQuery, "4ZpngI1uv+Uo3WQHEZmTQ5FNM+k=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/features/purchases/components/PurchasesList.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, d: __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
/*
"use client"

// components/PurchasesList.tsx
import React, {useEffect, useState} from "react";
import Image from "next/image";
import { getAllUsersPurchases } from "@/services/api/usersService";
import { Purchase } from "@/shared/types/user";
import {usePurchasesQuery} from "@/shared/hooks/usePurchasesQuery";

// Ця компонента – серверна, тому вона може бути async
export default function PurchasesList() {
    // Отримуємо дані прямо на сервері
    const purchases = usePurchasesQuery();
    //const purchases: Purchase[] = await getAllUsersPurchases();
    const [isMounted, setIsMounted] = useState(false);


    useEffect(() => {
        setIsMounted(true);
    }, []);

    if (!isMounted) {
        return null;
    }
    return (
        <div className="grid grid-cols-5 gap-4">
            {purchases.data?.map((purchase) => (
                <div key={purchase.id} className="border p-2">
                    <Image
                        alt={purchase.name}
                        src={purchase.img  || ""} // API повинно повертати img як URL
                        width={123}
                        height={124}

                        loading={"eager"}
                    />
                    <div className="mt-2 text-sm">
                        <p className="font-semibold">{purchase.name}</p>
                        <p className="text-gray-500">User ID: {purchase.userId}</p>
                        <p className="text-gray-400 text-xs">{purchase.date}</p>
                    </div>
                </div>
            ))}
        </div>
    );
}
*/ /*


// purchases/components/PurchasesList.tsx (СЕРВЕРНА КОМПОНЕНТА, без use client!)
import React from "react";
import Image from "next/image";
import { getAllUsersPurchases } from "@/services/api/usersService";
import { Purchase } from "@/shared/types/user";

export default async function PurchasesList() {
    const purchases: Purchase[] = await getAllUsersPurchases();

    return (
        <div className="grid grid-cols-5 gap-4">
            {purchases.map((purchase) => (
                <div key={purchase.id} className="border p-2">
                    <Image
                        alt={purchase.name}
                        src={purchase.img || ""}
                        width={123}
                        height={124}
                        // У Next Image в 13-й версії лентиве завантаження і так за замовчуванням,
                        // але якщо хочете явно, то можна вказати loading="lazy"
                        loading="lazy"
                    />
                    <div className="mt-2 text-sm">
                        <p className="font-semibold">{purchase.name}</p>
                        <p className="text-gray-500">User ID: {purchase.userId}</p>
                        <p className="text-gray-400 text-xs">{purchase.date}</p>
                    </div>
                </div>
            ))}
        </div>
    );
}
*/ __turbopack_context__.s({
    "default": (()=>PurchasesList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$shared$2f$hooks$2f$usePurchasesQuery$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/shared/hooks/usePurchasesQuery.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function PurchasesList() {
    _s();
    const { data: purchases, isLoading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$shared$2f$hooks$2f$usePurchasesQuery$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePurchasesQuery"])();
    if (isLoading) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: "Loading..."
    }, void 0, false, {
        fileName: "[project]/features/purchases/components/PurchasesList.tsx",
        lineNumber: 97,
        columnNumber: 27
    }, this);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "grid grid-cols-5 gap-4",
        children: purchases?.map((purchase)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "border p-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        alt: purchase.name,
                        src: purchase.img || "",
                        width: 123,
                        height: 124,
                        loading: "lazy"
                    }, void 0, false, {
                        fileName: "[project]/features/purchases/components/PurchasesList.tsx",
                        lineNumber: 103,
                        columnNumber: 21
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-2 text-sm",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "font-semibold",
                                children: purchase.name
                            }, void 0, false, {
                                fileName: "[project]/features/purchases/components/PurchasesList.tsx",
                                lineNumber: 111,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-gray-500",
                                children: [
                                    "User ID: ",
                                    purchase.userId
                                ]
                            }, void 0, true, {
                                fileName: "[project]/features/purchases/components/PurchasesList.tsx",
                                lineNumber: 112,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-gray-400 text-xs",
                                children: purchase.date
                            }, void 0, false, {
                                fileName: "[project]/features/purchases/components/PurchasesList.tsx",
                                lineNumber: 113,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/purchases/components/PurchasesList.tsx",
                        lineNumber: 110,
                        columnNumber: 21
                    }, this)
                ]
            }, purchase.id, true, {
                fileName: "[project]/features/purchases/components/PurchasesList.tsx",
                lineNumber: 102,
                columnNumber: 17
            }, this))
    }, void 0, false, {
        fileName: "[project]/features/purchases/components/PurchasesList.tsx",
        lineNumber: 100,
        columnNumber: 9
    }, this);
}
_s(PurchasesList, "gLfFBivwp3uxIZWmdyYzvxgFeGU=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$shared$2f$hooks$2f$usePurchasesQuery$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePurchasesQuery"]
    ];
});
_c = PurchasesList;
var _c;
__turbopack_context__.k.register(_c, "PurchasesList");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=_de8e4f01._.js.map