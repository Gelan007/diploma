(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/features_purchases_components_ModalContent_tsx_fd9c6ce2._.js", {

"[project]/features/purchases/components/ModalContent.tsx [app-client] (ecmascript, next/dynamic entry, async loader)": ((__turbopack_context__) => {

var { g: global, d: __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/_c6f6cd2b._.js",
  "static/chunks/features_purchases_components_ModalContent_tsx_14ce7ef4._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/features/purchases/components/ModalContent.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}}),
}]);