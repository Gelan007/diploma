(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/features_purchases_components_ModalContent_tsx_f33f171a._.js", {

"[project]/features/purchases/components/ModalContent.tsx [app-client] (ecmascript, next/dynamic entry, async loader)": ((__turbopack_context__) => {

var { g: global, d: __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_next_f5074bf6._.js",
  "static/chunks/_c6f6cd2b._.js",
  "static/chunks/features_purchases_components_ModalContent_tsx_7282c59b._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/features/purchases/components/ModalContent.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}}),
}]);