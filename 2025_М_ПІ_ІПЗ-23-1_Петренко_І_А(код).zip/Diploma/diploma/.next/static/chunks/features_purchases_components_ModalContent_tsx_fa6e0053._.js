(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/features_purchases_components_ModalContent_tsx_fa6e0053._.js", {

"[project]/features/purchases/components/ModalContent.tsx [app-client] (ecmascript, next/dynamic entry, async loader)": ((__turbopack_context__) => {

var { g: global, d: __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/features_purchases_components_ModalContent_tsx_43275178._.js",
  "static/chunks/features_purchases_components_ModalContent_tsx_e53dfd59._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/features/purchases/components/ModalContent.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}}),
}]);