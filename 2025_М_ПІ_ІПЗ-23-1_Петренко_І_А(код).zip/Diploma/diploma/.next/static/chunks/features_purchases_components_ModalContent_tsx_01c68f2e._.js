(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/features_purchases_components_ModalContent_tsx_01c68f2e._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/features_purchases_components_ModalContent_tsx_01c68f2e._.js",
  "chunks": [
    "static/chunks/features_purchases_components_ModalContent_tsx_43275178._.js"
  ],
  "source": "dynamic"
});
