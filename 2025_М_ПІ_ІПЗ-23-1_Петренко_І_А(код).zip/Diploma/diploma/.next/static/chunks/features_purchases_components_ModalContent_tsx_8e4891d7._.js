(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/features_purchases_components_ModalContent_tsx_8e4891d7._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/features_purchases_components_ModalContent_tsx_8e4891d7._.js",
  "chunks": [
    "static/chunks/_c6f6cd2b._.js"
  ],
  "source": "dynamic"
});
