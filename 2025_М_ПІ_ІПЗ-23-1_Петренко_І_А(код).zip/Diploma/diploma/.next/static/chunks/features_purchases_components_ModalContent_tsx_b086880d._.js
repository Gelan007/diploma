(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/features_purchases_components_ModalContent_tsx_b086880d._.js", {

"[project]/features/purchases/components/ModalContent.tsx [app-client] (ecmascript, next/dynamic entry, async loader)": ((__turbopack_context__) => {

var { g: global, d: __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_5a0b5ba7._.js",
  "static/chunks/_448a83cb._.js",
  "static/chunks/features_purchases_components_ModalContent_tsx_54075db2._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/features/purchases/components/ModalContent.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}}),
}]);