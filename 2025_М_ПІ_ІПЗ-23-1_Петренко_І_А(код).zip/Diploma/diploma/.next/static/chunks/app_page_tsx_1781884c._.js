(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_1781884c._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_1781884c._.js",
  "chunks": [
    "static/chunks/features_purchases_components_ModalContent_tsx_fec8de98._.js",
    "static/chunks/node_modules_900e6328._.js",
    "static/chunks/_7799327c._.js"
  ],
  "source": "dynamic"
});
