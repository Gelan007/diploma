(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_users-purchases_page_tsx_b8452c29._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_users-purchases_page_tsx_b8452c29._.js",
  "chunks": [
    "static/chunks/features_purchases_components_ModalContent_tsx_c82796e3._.js",
    "static/chunks/_c1f67c07._.js"
  ],
  "source": "dynamic"
});
