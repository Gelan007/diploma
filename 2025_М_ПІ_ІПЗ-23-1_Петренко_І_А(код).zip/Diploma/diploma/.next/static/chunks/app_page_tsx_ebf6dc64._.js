(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_ebf6dc64._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_ebf6dc64._.js",
  "chunks": [
    "static/chunks/node_modules_next_73b2dcbb._.js",
    "static/chunks/_7f253558._.js"
  ],
  "source": "dynamic"
});
