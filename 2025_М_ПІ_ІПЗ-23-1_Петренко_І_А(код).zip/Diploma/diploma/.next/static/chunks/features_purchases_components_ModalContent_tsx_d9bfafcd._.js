(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/features_purchases_components_ModalContent_tsx_d9bfafcd._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/features_purchases_components_ModalContent_tsx_d9bfafcd._.js",
  "chunks": [
    "static/chunks/features_purchases_components_ModalContent_tsx_43275178._.js"
  ],
  "source": "dynamic"
});
