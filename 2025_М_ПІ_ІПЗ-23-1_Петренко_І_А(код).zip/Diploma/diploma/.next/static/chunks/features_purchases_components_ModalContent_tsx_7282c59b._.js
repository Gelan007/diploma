(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/features_purchases_components_ModalContent_tsx_7282c59b._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/features_purchases_components_ModalContent_tsx_7282c59b._.js",
  "chunks": [
    "static/chunks/node_modules_next_f5074bf6._.js",
    "static/chunks/_c6f6cd2b._.js"
  ],
  "source": "dynamic"
});
