module.exports = {

"[project]/.next-internal/server/app/users-purchases/page/actions.js [app-rsc] (server actions loader, ecmascript)": (function(__turbopack_context__) {

var { g: global, d: __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),
"[project]/app/favicon.ico.mjs { IMAGE => \"[project]/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, d: __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/app/favicon.ico.mjs { IMAGE => \"[project]/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)"));
}}),
"[project]/app/layout.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, d: __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/app/layout.tsx [app-rsc] (ecmascript)"));
}}),
"[project]/services/api/usersService.ts [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, d: __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "getAllUsersPurchases": (()=>getAllUsersPurchases),
    "getUsers": (()=>getUsers)
});
const getUsers = async ()=>{
    const res = await fetch("http://localhost:3001/api/users");
    if (!res.ok) throw new Error("Failed to fetch users");
    return res.json();
};
const getAllUsersPurchases = async ()=>{
    const res = await fetch("http://localhost:3001/api/users/purchases");
    if (!res.ok) throw new Error("Failed to fetch purchases");
    return res.json();
};
}}),
"[project]/features/purchases/components/PurchasesList.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, d: __dirname } = __turbopack_context__;
{
/*
"use client"

// components/PurchasesList.tsx
import React, {useEffect, useState} from "react";
import Image from "next/image";
import { getAllUsersPurchases } from "@/services/api/usersService";
import { Purchase } from "@/shared/types/user";
import {usePurchasesQuery} from "@/shared/hooks/usePurchasesQuery";

// Ця компонента – серверна, тому вона може бути async
export default function PurchasesList() {
    // Отримуємо дані прямо на сервері
    const purchases = usePurchasesQuery();
    //const purchases: Purchase[] = await getAllUsersPurchases();
    const [isMounted, setIsMounted] = useState(false);


    useEffect(() => {
        setIsMounted(true);
    }, []);

    if (!isMounted) {
        return null;
    }
    return (
        <div className="grid grid-cols-5 gap-4">
            {purchases.data?.map((purchase) => (
                <div key={purchase.id} className="border p-2">
                    <Image
                        alt={purchase.name}
                        src={purchase.img  || ""} // API повинно повертати img як URL
                        width={123}
                        height={124}

                        loading={"eager"}
                    />
                    <div className="mt-2 text-sm">
                        <p className="font-semibold">{purchase.name}</p>
                        <p className="text-gray-500">User ID: {purchase.userId}</p>
                        <p className="text-gray-400 text-xs">{purchase.date}</p>
                    </div>
                </div>
            ))}
        </div>
    );
}
*/ // purchases/components/PurchasesList.tsx (СЕРВЕРНА КОМПОНЕНТА, без use client!)
__turbopack_context__.s({
    "default": (()=>PurchasesList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$api$2f$usersService$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/services/api/usersService.ts [app-rsc] (ecmascript)");
;
;
;
async function PurchasesList() {
    const purchases = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$api$2f$usersService$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getAllUsersPurchases"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "grid grid-cols-5 gap-4",
        children: purchases.map((purchase)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "border p-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        alt: purchase.name,
                        src: purchase.img || "",
                        width: 123,
                        height: 124,
                        // У Next Image в 13-й версії лентиве завантаження і так за замовчуванням,
                        // але якщо хочете явно, то можна вказати loading="lazy"
                        loading: "lazy"
                    }, void 0, false, {
                        fileName: "[project]/features/purchases/components/PurchasesList.tsx",
                        lineNumber: 64,
                        columnNumber: 21
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-2 text-sm",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "font-semibold",
                                children: purchase.name
                            }, void 0, false, {
                                fileName: "[project]/features/purchases/components/PurchasesList.tsx",
                                lineNumber: 74,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-gray-500",
                                children: [
                                    "User ID: ",
                                    purchase.userId
                                ]
                            }, void 0, true, {
                                fileName: "[project]/features/purchases/components/PurchasesList.tsx",
                                lineNumber: 75,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-gray-400 text-xs",
                                children: purchase.date
                            }, void 0, false, {
                                fileName: "[project]/features/purchases/components/PurchasesList.tsx",
                                lineNumber: 76,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/purchases/components/PurchasesList.tsx",
                        lineNumber: 73,
                        columnNumber: 21
                    }, this)
                ]
            }, purchase.id, true, {
                fileName: "[project]/features/purchases/components/PurchasesList.tsx",
                lineNumber: 63,
                columnNumber: 17
            }, this))
    }, void 0, false, {
        fileName: "[project]/features/purchases/components/PurchasesList.tsx",
        lineNumber: 61,
        columnNumber: 9
    }, this);
} /*

"use client";

import React from "react";
import Image from "next/image";
import { usePurchasesQuery } from "@/shared/hooks/usePurchasesQuery";

export default function PurchasesList() {
    const { data: purchases, isLoading } = usePurchasesQuery();

    if (isLoading) return <div>Loading...</div>;

    return (
        <div className="grid grid-cols-5 gap-4">
            {purchases?.map((purchase) => (
                <div key={purchase.id} className="border p-2">
                    <Image
                        alt={purchase.name}
                        src={purchase.img || ""}
                        width={123}
                        height={124}
                        loading="lazy"
                    />
                    <div className="mt-2 text-sm">
                        <p className="font-semibold">{purchase.name}</p>
                        <p className="text-gray-500">User ID: {purchase.userId}</p>
                        <p className="text-gray-400 text-xs">{purchase.date}</p>
                    </div>
                </div>
            ))}
        </div>
    );
}
*/ 
}}),
"[project]/shared/components/GoBackButton.tsx (client reference/proxy) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, d: __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "GoBackButton": (()=>GoBackButton)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const GoBackButton = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call GoBackButton() from the server but GoBackButton is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/shared/components/GoBackButton.tsx <module evaluation>", "GoBackButton");
}}),
"[project]/shared/components/GoBackButton.tsx (client reference/proxy)": ((__turbopack_context__) => {
"use strict";

var { g: global, d: __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "GoBackButton": (()=>GoBackButton)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const GoBackButton = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call GoBackButton() from the server but GoBackButton is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/shared/components/GoBackButton.tsx", "GoBackButton");
}}),
"[project]/shared/components/GoBackButton.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, d: __dirname } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$shared$2f$components$2f$GoBackButton$2e$tsx__$28$client__reference$2f$proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/shared/components/GoBackButton.tsx (client reference/proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$shared$2f$components$2f$GoBackButton$2e$tsx__$28$client__reference$2f$proxy$29$__ = __turbopack_context__.i("[project]/shared/components/GoBackButton.tsx (client reference/proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$shared$2f$components$2f$GoBackButton$2e$tsx__$28$client__reference$2f$proxy$29$__);
}}),
"[project]/features/purchases/components/PurchasesModal.tsx (client reference/proxy) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, d: __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/features/purchases/components/PurchasesModal.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/features/purchases/components/PurchasesModal.tsx <module evaluation>", "default");
}}),
"[project]/features/purchases/components/PurchasesModal.tsx (client reference/proxy)": ((__turbopack_context__) => {
"use strict";

var { g: global, d: __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/features/purchases/components/PurchasesModal.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/features/purchases/components/PurchasesModal.tsx", "default");
}}),
"[project]/features/purchases/components/PurchasesModal.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, d: __dirname } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$purchases$2f$components$2f$PurchasesModal$2e$tsx__$28$client__reference$2f$proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/features/purchases/components/PurchasesModal.tsx (client reference/proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$purchases$2f$components$2f$PurchasesModal$2e$tsx__$28$client__reference$2f$proxy$29$__ = __turbopack_context__.i("[project]/features/purchases/components/PurchasesModal.tsx (client reference/proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$purchases$2f$components$2f$PurchasesModal$2e$tsx__$28$client__reference$2f$proxy$29$__);
}}),
"[project]/app/users-purchases/page.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, d: __dirname } = __turbopack_context__;
{
/*
"use client"
import React from "react";
import { LazyLoadImage } from "react-lazy-load-image-component";
import "react-lazy-load-image-component/src/effects/blur.css";
import {usePurchasesQuery} from "@/shared/hooks/usePurchasesQuery";
import Image from "next/image";

interface ImageData {
    id: number;
    src: string;
    alt: string;
}
/!*!// Приклад масиву зображень. Реальні дані можуть завантажуватися із API або бути статичними.
const images: ImageData[] = [
    { id: 1, src: "/images/image1.jpg", alt: "Зображення 1" },
    { id: 2, src: "/images/image2.jpg", alt: "Зображення 2" },
    { id: 3, src: "/images/image3.jpg", alt: "Зображення 3" },
    { id: 4, src: "/images/image4.jpg", alt: "Зображення 4" },
    { id: 5, src: "/images/image5.jpg", alt: "Зображення 5" },
    // Додайте більше зображень за потреби
];*!/

const UsersOrdersPage = () => {
    const purchases = usePurchasesQuery();
    console.log(purchases)
    return (
        <div className="p-3">
            <h1 className="text-2xl font-bold mb-4">Users last purchases</h1>
           {/!* <Image
                src="https://s3.amazonaws.com/my-bucket/profile.png"
                alt="Picture of the author"
                width={500}
                height={500}
            />*!/}
            <div className="grid grid-cols-3 gap-4">
                {purchases.data?.map((purchase, index) => (
                    <div key={index} className="border p-2">
                        {/!*<LazyLoadImage
                            alt={image.name}
                            effect="blur" // додає ефект розмиття перед завантаженням
                            src={image.img}
                            width="100%"
                        />*!/}
                        <Image alt="Iphone" src={"https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_max_desert_titanium_pdp_image_position_1__ce-ww_2.webp"} width={123} height={124} />
                    </div>
                ))}
            </div>
        </div>
    );
};

export default UsersOrdersPage;
*/ /*
// app/users-orders/page.tsx або pages/users-orders.tsx (залежно від структури проєкту)
import React, {Suspense} from "react";
import dynamic from "next/dynamic";
import {GoBackButton} from "@/shared/components/GoBackButton";

const DynamicPurchasesList = dynamic(
    () => import("@/features/purchases/components/PurchasesList"),
    {suspense: true} as any
);

export default function UsersOrdersPage() {
    return (
        <div className="p-3">
            <h1 className="text-2xl font-bold mb-4">Users Last Purchases</h1>
            <GoBackButton />

            {/!* Обгортаємо динамічну компоненту в Suspense для показу fallback під час завантаження *!/}
            <Suspense fallback={<div>Loading purchases...</div>}>
                <DynamicPurchasesList/>
            </Suspense>
        </div>
    );
}
*/ __turbopack_context__.s({
    "default": (()=>UsersOrdersPage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$purchases$2f$components$2f$PurchasesList$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/purchases/components/PurchasesList.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$shared$2f$components$2f$GoBackButton$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/shared/components/GoBackButton.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$purchases$2f$components$2f$PurchasesModal$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/purchases/components/PurchasesModal.tsx [app-rsc] (ecmascript)");
;
;
;
;
function UsersOrdersPage() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "p-3",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                className: "text-2xl font-bold mb-4",
                children: "Users Last Purchases"
            }, void 0, false, {
                fileName: "[project]/app/users-purchases/page.tsx",
                lineNumber: 94,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$shared$2f$components$2f$GoBackButton$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["GoBackButton"], {}, void 0, false, {
                fileName: "[project]/app/users-purchases/page.tsx",
                lineNumber: 95,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$purchases$2f$components$2f$PurchasesList$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/app/users-purchases/page.tsx",
                lineNumber: 101,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$purchases$2f$components$2f$PurchasesModal$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/app/users-purchases/page.tsx",
                lineNumber: 102,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/users-purchases/page.tsx",
        lineNumber: 93,
        columnNumber: 9
    }, this);
}
}}),
"[project]/app/users-purchases/page.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, d: __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/app/users-purchases/page.tsx [app-rsc] (ecmascript)"));
}}),

};

//# sourceMappingURL=_2cb8f850._.js.map