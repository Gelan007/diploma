module.exports = {

"[project]/features/purchases/components/PurchasesList.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, d: __dirname } = __turbopack_context__;
{
/*
"use client"

// components/PurchasesList.tsx
import React, {useEffect, useState} from "react";
import Image from "next/image";
import { getAllUsersPurchases } from "@/services/api/usersService";
import { Purchase } from "@/shared/types/user";
import {usePurchasesQuery} from "@/shared/hooks/usePurchasesQuery";

// Ця компонента – серверна, тому вона може бути async
export default function PurchasesList() {
    // Отримуємо дані прямо на сервері
    const purchases = usePurchasesQuery();
    //const purchases: Purchase[] = await getAllUsersPurchases();
    const [isMounted, setIsMounted] = useState(false);


    useEffect(() => {
        setIsMounted(true);
    }, []);

    if (!isMounted) {
        return null;
    }
    return (
        <div className="grid grid-cols-5 gap-4">
            {purchases.data?.map((purchase) => (
                <div key={purchase.id} className="border p-2">
                    <Image
                        alt={purchase.name}
                        src={purchase.img  || ""} // API повинно повертати img як URL
                        width={123}
                        height={124}

                        loading={"eager"}
                    />
                    <div className="mt-2 text-sm">
                        <p className="font-semibold">{purchase.name}</p>
                        <p className="text-gray-500">User ID: {purchase.userId}</p>
                        <p className="text-gray-400 text-xs">{purchase.date}</p>
                    </div>
                </div>
            ))}
        </div>
    );
}
*/ /*


// purchases/components/PurchasesList.tsx (СЕРВЕРНА КОМПОНЕНТА, без use client!)
import React from "react";
import Image from "next/image";
import { getAllUsersPurchases } from "@/services/api/usersService";
import { Purchase } from "@/shared/types/user";

export default async function PurchasesList() {
    const purchases: Purchase[] = await getAllUsersPurchases();

    return (
        <div className="grid grid-cols-5 gap-4">
            {purchases.map((purchase) => (
                <div key={purchase.id} className="border p-2">
                    <Image
                        alt={purchase.name}
                        src={purchase.img || ""}
                        width={123}
                        height={124}
                        // У Next Image в 13-й версії лентиве завантаження і так за замовчуванням,
                        // але якщо хочете явно, то можна вказати loading="lazy"
                        loading="lazy"
                    />
                    <div className="mt-2 text-sm">
                        <p className="font-semibold">{purchase.name}</p>
                        <p className="text-gray-500">User ID: {purchase.userId}</p>
                        <p className="text-gray-400 text-xs">{purchase.date}</p>
                    </div>
                </div>
            ))}
        </div>
    );
}
*/ __turbopack_context__.s({
    "default": (()=>PurchasesList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-ssr] (ecmascript)");
"use client";
;
;
function PurchasesList() {
    // const { data: purchases, isLoading } = usePurchasesQuery();
    // if (isLoading) return <div>Loading...</div>;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "grid grid-cols-5 gap-4",
        children: purchases?.map((purchase)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "border p-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        alt: purchase.name,
                        src: purchase.img || "",
                        width: 123,
                        height: 124,
                        loading: "lazy"
                    }, void 0, false, {
                        fileName: "[project]/features/purchases/components/PurchasesList.tsx",
                        lineNumber: 100,
                        columnNumber: 21
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-2 text-sm",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "font-semibold",
                                children: purchase.name
                            }, void 0, false, {
                                fileName: "[project]/features/purchases/components/PurchasesList.tsx",
                                lineNumber: 108,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-gray-500",
                                children: [
                                    "User ID: ",
                                    purchase.userId
                                ]
                            }, void 0, true, {
                                fileName: "[project]/features/purchases/components/PurchasesList.tsx",
                                lineNumber: 109,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-gray-400 text-xs",
                                children: purchase.date
                            }, void 0, false, {
                                fileName: "[project]/features/purchases/components/PurchasesList.tsx",
                                lineNumber: 110,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/purchases/components/PurchasesList.tsx",
                        lineNumber: 107,
                        columnNumber: 21
                    }, this)
                ]
            }, purchase.id, true, {
                fileName: "[project]/features/purchases/components/PurchasesList.tsx",
                lineNumber: 99,
                columnNumber: 17
            }, this))
    }, void 0, false, {
        fileName: "[project]/features/purchases/components/PurchasesList.tsx",
        lineNumber: 97,
        columnNumber: 9
    }, this);
}
}}),
"[project]/features/purchases/components/ModalContent.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, d: __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>ModalContent)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$purchases$2f$components$2f$PurchasesList$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/purchases/components/PurchasesList.tsx [app-ssr] (ecmascript)");
"use client";
;
;
function ModalContent({ onClose }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed top-[50px] left-1/2 -translate-x-1/2 p-5 border border-black bg-white z-[9999]",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-xl font-semibold",
                children: "Heavy Modal Content"
            }, void 0, false, {
                fileName: "[project]/features/purchases/components/ModalContent.tsx",
                lineNumber: 8,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mt-2",
                children: "This content is loaded “lazily” with dynamic import"
            }, void 0, false, {
                fileName: "[project]/features/purchases/components/ModalContent.tsx",
                lineNumber: 9,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: onClose,
                className: "text-blue-400 cursor-pointer mt-4",
                children: "Close Modal"
            }, void 0, false, {
                fileName: "[project]/features/purchases/components/ModalContent.tsx",
                lineNumber: 10,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-5 overflow-y-auto max-h-[60vh]",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$purchases$2f$components$2f$PurchasesList$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/features/purchases/components/ModalContent.tsx",
                    lineNumber: 12,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/purchases/components/ModalContent.tsx",
                lineNumber: 11,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/purchases/components/ModalContent.tsx",
        lineNumber: 7,
        columnNumber: 9
    }, this);
}
}}),
"[project]/features/purchases/components/ModalContent.tsx [app-ssr] (ecmascript, next/dynamic entry)": ((__turbopack_context__) => {

var { g: global, d: __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/features/purchases/components/ModalContent.tsx [app-ssr] (ecmascript)"));
}}),

};

//# sourceMappingURL=features_purchases_components_c5eb0b17._.js.map