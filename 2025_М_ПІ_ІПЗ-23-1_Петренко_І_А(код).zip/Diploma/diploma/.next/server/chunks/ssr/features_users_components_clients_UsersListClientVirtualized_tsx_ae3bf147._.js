module.exports = {

"[project]/features/users/components/clients/UsersListClientVirtualized.tsx [app-rsc] (ecmascript, next/dynamic entry, async loader)": ((__turbopack_context__) => {

var { g: global, d: __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/features_users_components_clients_UsersListClientVirtualized_tsx_52c35e3b._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/features/users/components/clients/UsersListClientVirtualized.tsx [app-rsc] (ecmascript, next/dynamic entry)");
    });
});
}}),

};