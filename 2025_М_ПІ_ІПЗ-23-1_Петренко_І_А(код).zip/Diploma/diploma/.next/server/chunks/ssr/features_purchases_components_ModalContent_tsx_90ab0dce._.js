module.exports = {

"[project]/features/purchases/components/ModalContent.tsx [app-ssr] (ecmascript, next/dynamic entry, async loader)": ((__turbopack_context__) => {

var { g: global, d: __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/node_modules_b44005cc._.js",
  "server/chunks/ssr/_29cc61cc._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/features/purchases/components/ModalContent.tsx [app-ssr] (ecmascript, next/dynamic entry)");
    });
});
}}),

};