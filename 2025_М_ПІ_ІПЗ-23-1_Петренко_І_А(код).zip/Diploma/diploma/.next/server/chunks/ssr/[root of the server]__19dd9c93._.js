module.exports = {

"[project]/assets/images/user.png (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, d: __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/user.e16bc7ea.png");}}),
"[project]/assets/images/user.png.mjs { IMAGE => \"[project]/assets/images/user.png (static in ecmascript)\" } [app-ssr] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, d: __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$assets$2f$images$2f$user$2e$png__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/assets/images/user.png (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$assets$2f$images$2f$user$2e$png__$28$static__in__ecmascript$29$__["default"],
    width: 512,
    height: 512,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABE0lEQVR42gEIAff+AAECAwIaL0BBR4W4v1Sj5fFOnuLxOXmxvxIpPUEBAgICABovQEFRmNHaUJnW4iNFYWUfQmBlPYrO4jaBxNoPJjtBAEeFuL9ZrPD/NWqWnwECBAMBAgMDJl6PnziQ4f8maai/AFam6fZSpu3/O322xA0dLC4LGysuKm+uxDGK3v8qgtT2AE+h5vZFktTlHT9eZBo9XGQXO1tkFDhZZCZ4xeUkfNL2ADl5sb8tZJSgAgMFBQAAAQAAAAEAAQMFBRZQiaAYXaG/ABIpPUEtbKW2EzFNVgUOFxoEDRcaCytKVhVYmrYHIDhBAAECAgIPJjtBJGOesiJqrsgdZazIFleXsgcgN0EAAQICaKxcwpqYXqsAAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 8
};
}}),
"[project]/features/users/components/UserCard.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, d: __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$assets$2f$images$2f$user$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$assets$2f$images$2f$user$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/assets/images/user.png.mjs { IMAGE => "[project]/assets/images/user.png (static in ecmascript)" } [app-ssr] (structured image object, ecmascript)');
;
;
;
;
const UserCard = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].memo(({ user, onClick, className })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `flex flex-col bg-white rounded-lg shadow-sm p-3 ${className}`,
        onClick: ()=>onClick(user.id),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                src: __TURBOPACK__imported__module__$5b$project$5d2f$assets$2f$images$2f$user$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$assets$2f$images$2f$user$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                alt: "user"
            }, void 0, false, {
                fileName: "[project]/features/users/components/UserCard.tsx",
                lineNumber: 14,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-lg text-black font-bold",
                children: `${user.firstName} ${user.lastName}`
            }, void 0, false, {
                fileName: "[project]/features/users/components/UserCard.tsx",
                lineNumber: 15,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-base text-grey font-semibold",
                children: [
                    "age: ",
                    `${user.age}`
                ]
            }, void 0, true, {
                fileName: "[project]/features/users/components/UserCard.tsx",
                lineNumber: 16,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-base text-grey font-semibold",
                children: [
                    "phone: ",
                    `${user.phone}`
                ]
            }, void 0, true, {
                fileName: "[project]/features/users/components/UserCard.tsx",
                lineNumber: 17,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-base text-grey font-semibold",
                children: [
                    "email: ",
                    `${user.email}`
                ]
            }, void 0, true, {
                fileName: "[project]/features/users/components/UserCard.tsx",
                lineNumber: 18,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-base text-grey font-semibold",
                children: [
                    "city: ",
                    `${user.city}`
                ]
            }, void 0, true, {
                fileName: "[project]/features/users/components/UserCard.tsx",
                lineNumber: 19,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-base text-grey font-semibold",
                children: [
                    "country: ",
                    `${user.country}`
                ]
            }, void 0, true, {
                fileName: "[project]/features/users/components/UserCard.tsx",
                lineNumber: 20,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/users/components/UserCard.tsx",
        lineNumber: 13,
        columnNumber: 9
    }, this);
});
const __TURBOPACK__default__export__ = UserCard;
}}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, d: __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, d: __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, d: __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[project]/features/purchases/components/PurchasesModal.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, d: __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>PurchasesModal)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/shared/lib/app-dynamic.js [app-ssr] (ecmascript)");
;
"use client";
;
;
;
//import DynamicModalContent from "./ModalContent"
const DynamicModalContent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.r("[project]/features/purchases/components/ModalContent.tsx [app-ssr] (ecmascript, next/dynamic entry, async loader)")(__turbopack_context__.i), {
    loadableGenerated: {
        modules: [
            "[project]/features/purchases/components/ModalContent.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    loading: ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            children: "Loading..."
        }, void 0, false, {
            fileName: "[project]/features/purchases/components/PurchasesModal.tsx",
            lineNumber: 6,
            columnNumber: 20
        }, this)
});
function PurchasesModal() {
    const [open, setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const handleOpenModal = ()=>setOpen(true);
    const handleCloseModal = ()=>setOpen(false);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                className: "mb-4 p-2 bg-purple-500 text-white rounded",
                onClick: handleOpenModal,
                children: "Open Modal (lazy-load)"
            }, void 0, false, {
                fileName: "[project]/features/purchases/components/PurchasesModal.tsx",
                lineNumber: 15,
                columnNumber: 13
            }, this),
            open && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(DynamicModalContent, {
                onClose: handleCloseModal
            }, void 0, false, {
                fileName: "[project]/features/purchases/components/PurchasesModal.tsx",
                lineNumber: 23,
                columnNumber: 17
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/purchases/components/PurchasesModal.tsx",
        lineNumber: 14,
        columnNumber: 9
    }, this);
}
}}),
"[project]/shared/constants.ts [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, d: __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "purchases": (()=>purchases)
});
const purchases = [
    {
        "userId": 1,
        "id": "iphone-id-1",
        "name": "iPhone Model 1",
        "date": "2023-01-01",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-black-select-2020_3.webp"
    },
    {
        "userId": 2,
        "id": "iphone-id-2",
        "name": "iPhone Model 2",
        "date": "2023-02-02",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-blue-select-2020_3_1_1.jpg"
    },
    {
        "userId": 3,
        "id": "iphone-id-3",
        "name": "iPhone Model 3",
        "date": "2023-03-03",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_max_desert_titanium_pdp_image_position_1__ce-ww_2.webp"
    },
    {
        "userId": 4,
        "id": "iphone-id-4",
        "name": "iPhone Model 4",
        "date": "2023-04-04",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_15_plus_black_pdp_image_position-1__ww-en.jpg"
    },
    {
        "userId": 5,
        "id": "iphone-id-5",
        "name": "iPhone Model 5",
        "date": "2023-05-05",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_max_desert_titanium_pdp_image_position_1__ce-ww_2.webp"
    },
    {
        "userId": 6,
        "id": "iphone-id-6",
        "name": "iPhone Model 6",
        "date": "2023-06-06",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_desert_titanium_pdp_image_position_1__ce-ww_1.webp"
    },
    {
        "userId": 7,
        "id": "iphone-id-7",
        "name": "iPhone Model 7",
        "date": "2023-07-07",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_desert_titanium_pdp_image_position_1__ce-ww_1.webp"
    },
    {
        "userId": 8,
        "id": "iphone-id-8",
        "name": "iPhone Model 8",
        "date": "2023-08-08",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-black-select-2020_3.webp"
    },
    {
        "userId": 9,
        "id": "iphone-id-9",
        "name": "iPhone Model 9",
        "date": "2023-09-09",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-black-select-2020_3.webp"
    },
    {
        "userId": 10,
        "id": "iphone-id-10",
        "name": "iPhone Model 10",
        "date": "2023-10-10",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-black-select-2020_3.webp"
    },
    {
        "userId": 11,
        "id": "iphone-id-11",
        "name": "iPhone Model 11",
        "date": "2023-11-11",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-black-select-2020_3.webp"
    },
    {
        "userId": 12,
        "id": "iphone-id-12",
        "name": "iPhone Model 12",
        "date": "2023-12-12",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_desert_titanium_pdp_image_position_1__ce-ww_1.webp"
    },
    {
        "userId": 13,
        "id": "iphone-id-13",
        "name": "iPhone Model 13",
        "date": "2023-01-13",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/w/w/wwen_iphone14_q422_productred_pdp_image_position-1a_3.jpg"
    },
    {
        "userId": 14,
        "id": "iphone-id-14",
        "name": "iPhone Model 14",
        "date": "2023-02-14",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-blue-select-2020_3_1_1.jpg"
    },
    {
        "userId": 15,
        "id": "iphone-id-15",
        "name": "iPhone Model 15",
        "date": "2023-03-15",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_15_plus_black_pdp_image_position-1__ww-en.jpg"
    },
    {
        "userId": 16,
        "id": "iphone-id-16",
        "name": "iPhone Model 16",
        "date": "2023-04-16",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_desert_titanium_pdp_image_position_1__ce-ww_1.webp"
    },
    {
        "userId": 17,
        "id": "iphone-id-17",
        "name": "iPhone Model 17",
        "date": "2023-05-17",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-black-select-2020_3.webp"
    },
    {
        "userId": 18,
        "id": "iphone-id-18",
        "name": "iPhone Model 18",
        "date": "2023-06-18",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_max_desert_titanium_pdp_image_position_1__ce-ww_2.webp"
    },
    {
        "userId": 19,
        "id": "iphone-id-19",
        "name": "iPhone Model 19",
        "date": "2023-07-19",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_black_pdp_image_position_1__ce-ww1725952011.webp"
    },
    {
        "userId": 20,
        "id": "iphone-id-20",
        "name": "iPhone Model 20",
        "date": "2023-08-20",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-blue-select-2020_3_1_1.jpg"
    },
    {
        "userId": 21,
        "id": "iphone-id-21",
        "name": "iPhone Model 21",
        "date": "2023-09-21",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_black_pdp_image_position_1__ce-ww1725952011.webp"
    },
    {
        "userId": 22,
        "id": "iphone-id-22",
        "name": "iPhone Model 22",
        "date": "2023-10-22",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-blue-select-2020_3_1_1.jpg"
    },
    {
        "userId": 23,
        "id": "iphone-id-23",
        "name": "iPhone Model 23",
        "date": "2023-11-23",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_max_desert_titanium_pdp_image_position_1__ce-ww_2.webp"
    },
    {
        "userId": 24,
        "id": "iphone-id-24",
        "name": "iPhone Model 24",
        "date": "2023-12-24",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_15_plus_black_pdp_image_position-1__ww-en.jpg"
    },
    {
        "userId": 25,
        "id": "iphone-id-25",
        "name": "iPhone Model 25",
        "date": "2023-01-25",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_black_pdp_image_position_1__ce-ww1725952011.webp"
    },
    {
        "userId": 26,
        "id": "iphone-id-26",
        "name": "iPhone Model 26",
        "date": "2023-02-26",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_black_pdp_image_position_1__ce-ww1725952011.webp"
    },
    {
        "userId": 27,
        "id": "iphone-id-27",
        "name": "iPhone Model 27",
        "date": "2023-03-27",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/w/w/wwen_iphone14_q422_productred_pdp_image_position-1a_3.jpg"
    },
    {
        "userId": 28,
        "id": "iphone-id-28",
        "name": "iPhone Model 28",
        "date": "2023-04-28",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_max_desert_titanium_pdp_image_position_1__ce-ww_2.webp"
    },
    {
        "userId": 29,
        "id": "iphone-id-29",
        "name": "iPhone Model 29",
        "date": "2023-05-01",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_desert_titanium_pdp_image_position_1__ce-ww_1.webp"
    },
    {
        "userId": 30,
        "id": "iphone-id-30",
        "name": "iPhone Model 30",
        "date": "2023-06-02",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-black-select-2020_3.webp"
    },
    {
        "userId": 31,
        "id": "iphone-id-31",
        "name": "iPhone Model 31",
        "date": "2023-07-03",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/w/w/wwen_iphone14_q422_productred_pdp_image_position-1a_3.jpg"
    },
    {
        "userId": 32,
        "id": "iphone-id-32",
        "name": "iPhone Model 32",
        "date": "2023-08-04",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-blue-select-2020_3_1_1.jpg"
    },
    {
        "userId": 33,
        "id": "iphone-id-33",
        "name": "iPhone Model 33",
        "date": "2023-09-05",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_max_desert_titanium_pdp_image_position_1__ce-ww_2.webp"
    },
    {
        "userId": 34,
        "id": "iphone-id-34",
        "name": "iPhone Model 34",
        "date": "2023-10-06",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_15_plus_black_pdp_image_position-1__ww-en.jpg"
    },
    {
        "userId": 35,
        "id": "iphone-id-35",
        "name": "iPhone Model 35",
        "date": "2023-11-07",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_max_desert_titanium_pdp_image_position_1__ce-ww_2.webp"
    },
    {
        "userId": 36,
        "id": "iphone-id-36",
        "name": "iPhone Model 36",
        "date": "2023-12-08",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-blue-select-2020_3_1_1.jpg"
    },
    {
        "userId": 37,
        "id": "iphone-id-37",
        "name": "iPhone Model 37",
        "date": "2023-01-09",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_black_pdp_image_position_1__ce-ww1725952011.webp"
    },
    {
        "userId": 38,
        "id": "iphone-id-38",
        "name": "iPhone Model 38",
        "date": "2023-02-10",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_black_pdp_image_position_1__ce-ww1725952011.webp"
    },
    {
        "userId": 39,
        "id": "iphone-id-39",
        "name": "iPhone Model 39",
        "date": "2023-03-11",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-black-select-2020_3.webp"
    },
    {
        "userId": 40,
        "id": "iphone-id-40",
        "name": "iPhone Model 40",
        "date": "2023-04-12",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-black-select-2020_3.webp"
    },
    {
        "userId": 41,
        "id": "iphone-id-41",
        "name": "iPhone Model 41",
        "date": "2023-05-13",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_desert_titanium_pdp_image_position_1__ce-ww_1.webp"
    },
    {
        "userId": 42,
        "id": "iphone-id-42",
        "name": "iPhone Model 42",
        "date": "2023-06-14",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_desert_titanium_pdp_image_position_1__ce-ww_1.webp"
    },
    {
        "userId": 43,
        "id": "iphone-id-43",
        "name": "iPhone Model 43",
        "date": "2023-07-15",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_max_desert_titanium_pdp_image_position_1__ce-ww_2.webp"
    },
    {
        "userId": 44,
        "id": "iphone-id-44",
        "name": "iPhone Model 44",
        "date": "2023-08-16",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_desert_titanium_pdp_image_position_1__ce-ww_1.webp"
    },
    {
        "userId": 45,
        "id": "iphone-id-45",
        "name": "iPhone Model 45",
        "date": "2023-09-17",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_black_pdp_image_position_1__ce-ww1725952011.webp"
    },
    {
        "userId": 46,
        "id": "iphone-id-46",
        "name": "iPhone Model 46",
        "date": "2023-10-18",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-blue-select-2020_3_1_1.jpg"
    },
    {
        "userId": 47,
        "id": "iphone-id-47",
        "name": "iPhone Model 47",
        "date": "2023-11-19",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-black-select-2020_3.webp"
    },
    {
        "userId": 48,
        "id": "iphone-id-48",
        "name": "iPhone Model 48",
        "date": "2023-12-20",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_15_plus_black_pdp_image_position-1__ww-en.jpg"
    },
    {
        "userId": 49,
        "id": "iphone-id-49",
        "name": "iPhone Model 49",
        "date": "2023-01-21",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_15_plus_black_pdp_image_position-1__ww-en.jpg"
    },
    {
        "userId": 50,
        "id": "iphone-id-50",
        "name": "iPhone Model 50",
        "date": "2023-02-22",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_desert_titanium_pdp_image_position_1__ce-ww_1.webp"
    },
    {
        "userId": 51,
        "id": "iphone-id-51",
        "name": "iPhone Model 51",
        "date": "2023-03-23",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-blue-select-2020_3_1_1.jpg"
    },
    {
        "userId": 52,
        "id": "iphone-id-52",
        "name": "iPhone Model 52",
        "date": "2023-04-24",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-blue-select-2020_3_1_1.jpg"
    },
    {
        "userId": 53,
        "id": "iphone-id-53",
        "name": "iPhone Model 53",
        "date": "2023-05-25",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_desert_titanium_pdp_image_position_1__ce-ww_1.webp"
    },
    {
        "userId": 54,
        "id": "iphone-id-54",
        "name": "iPhone Model 54",
        "date": "2023-06-26",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_desert_titanium_pdp_image_position_1__ce-ww_1.webp"
    },
    {
        "userId": 55,
        "id": "iphone-id-55",
        "name": "iPhone Model 55",
        "date": "2023-07-27",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_black_pdp_image_position_1__ce-ww1725952011.webp"
    },
    {
        "userId": 56,
        "id": "iphone-id-56",
        "name": "iPhone Model 56",
        "date": "2023-08-28",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_black_pdp_image_position_1__ce-ww1725952011.webp"
    },
    {
        "userId": 57,
        "id": "iphone-id-57",
        "name": "iPhone Model 57",
        "date": "2023-09-01",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-blue-select-2020_3_1_1.jpg"
    },
    {
        "userId": 58,
        "id": "iphone-id-58",
        "name": "iPhone Model 58",
        "date": "2023-10-02",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/w/w/wwen_iphone14_q422_productred_pdp_image_position-1a_3.jpg"
    },
    {
        "userId": 59,
        "id": "iphone-id-59",
        "name": "iPhone Model 59",
        "date": "2023-11-03",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-black-select-2020_3.webp"
    },
    {
        "userId": 60,
        "id": "iphone-id-60",
        "name": "iPhone Model 60",
        "date": "2023-12-04",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-blue-select-2020_3_1_1.jpg"
    },
    {
        "userId": 61,
        "id": "iphone-id-61",
        "name": "iPhone Model 61",
        "date": "2023-01-05",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_black_pdp_image_position_1__ce-ww1725952011.webp"
    },
    {
        "userId": 62,
        "id": "iphone-id-62",
        "name": "iPhone Model 62",
        "date": "2023-02-06",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_max_desert_titanium_pdp_image_position_1__ce-ww_2.webp"
    },
    {
        "userId": 63,
        "id": "iphone-id-63",
        "name": "iPhone Model 63",
        "date": "2023-03-07",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_max_desert_titanium_pdp_image_position_1__ce-ww_2.webp"
    },
    {
        "userId": 64,
        "id": "iphone-id-64",
        "name": "iPhone Model 64",
        "date": "2023-04-08",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-blue-select-2020_3_1_1.jpg"
    },
    {
        "userId": 65,
        "id": "iphone-id-65",
        "name": "iPhone Model 65",
        "date": "2023-05-09",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_15_plus_black_pdp_image_position-1__ww-en.jpg"
    },
    {
        "userId": 66,
        "id": "iphone-id-66",
        "name": "iPhone Model 66",
        "date": "2023-06-10",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-blue-select-2020_3_1_1.jpg"
    },
    {
        "userId": 67,
        "id": "iphone-id-67",
        "name": "iPhone Model 67",
        "date": "2023-07-11",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_desert_titanium_pdp_image_position_1__ce-ww_1.webp"
    },
    {
        "userId": 68,
        "id": "iphone-id-68",
        "name": "iPhone Model 68",
        "date": "2023-08-12",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_15_plus_black_pdp_image_position-1__ww-en.jpg"
    },
    {
        "userId": 69,
        "id": "iphone-id-69",
        "name": "iPhone Model 69",
        "date": "2023-09-13",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_15_plus_black_pdp_image_position-1__ww-en.jpg"
    },
    {
        "userId": 70,
        "id": "iphone-id-70",
        "name": "iPhone Model 70",
        "date": "2023-10-14",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-blue-select-2020_3_1_1.jpg"
    },
    {
        "userId": 71,
        "id": "iphone-id-71",
        "name": "iPhone Model 71",
        "date": "2023-11-15",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/w/w/wwen_iphone14_q422_productred_pdp_image_position-1a_3.jpg"
    },
    {
        "userId": 72,
        "id": "iphone-id-72",
        "name": "iPhone Model 72",
        "date": "2023-12-16",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_15_plus_black_pdp_image_position-1__ww-en.jpg"
    },
    {
        "userId": 73,
        "id": "iphone-id-73",
        "name": "iPhone Model 73",
        "date": "2023-01-17",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-black-select-2020_3.webp"
    },
    {
        "userId": 74,
        "id": "iphone-id-74",
        "name": "iPhone Model 74",
        "date": "2023-02-18",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-black-select-2020_3.webp"
    },
    {
        "userId": 75,
        "id": "iphone-id-75",
        "name": "iPhone Model 75",
        "date": "2023-03-19",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/w/w/wwen_iphone14_q422_productred_pdp_image_position-1a_3.jpg"
    },
    {
        "userId": 76,
        "id": "iphone-id-76",
        "name": "iPhone Model 76",
        "date": "2023-04-20",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/w/w/wwen_iphone14_q422_productred_pdp_image_position-1a_3.jpg"
    },
    {
        "userId": 77,
        "id": "iphone-id-77",
        "name": "iPhone Model 77",
        "date": "2023-05-21",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_black_pdp_image_position_1__ce-ww1725952011.webp"
    },
    {
        "userId": 78,
        "id": "iphone-id-78",
        "name": "iPhone Model 78",
        "date": "2023-06-22",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_max_desert_titanium_pdp_image_position_1__ce-ww_2.webp"
    },
    {
        "userId": 79,
        "id": "iphone-id-79",
        "name": "iPhone Model 79",
        "date": "2023-07-23",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_15_plus_black_pdp_image_position-1__ww-en.jpg"
    },
    {
        "userId": 80,
        "id": "iphone-id-80",
        "name": "iPhone Model 80",
        "date": "2023-08-24",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_desert_titanium_pdp_image_position_1__ce-ww_1.webp"
    },
    {
        "userId": 81,
        "id": "iphone-id-81",
        "name": "iPhone Model 81",
        "date": "2023-09-25",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_15_plus_black_pdp_image_position-1__ww-en.jpg"
    },
    {
        "userId": 82,
        "id": "iphone-id-82",
        "name": "iPhone Model 82",
        "date": "2023-10-26",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-black-select-2020_3.webp"
    },
    {
        "userId": 83,
        "id": "iphone-id-83",
        "name": "iPhone Model 83",
        "date": "2023-11-27",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_max_desert_titanium_pdp_image_position_1__ce-ww_2.webp"
    },
    {
        "userId": 84,
        "id": "iphone-id-84",
        "name": "iPhone Model 84",
        "date": "2023-12-28",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_15_plus_black_pdp_image_position-1__ww-en.jpg"
    },
    {
        "userId": 85,
        "id": "iphone-id-85",
        "name": "iPhone Model 85",
        "date": "2023-01-01",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/w/w/wwen_iphone14_q422_productred_pdp_image_position-1a_3.jpg"
    },
    {
        "userId": 86,
        "id": "iphone-id-86",
        "name": "iPhone Model 86",
        "date": "2023-02-02",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_black_pdp_image_position_1__ce-ww1725952011.webp"
    },
    {
        "userId": 87,
        "id": "iphone-id-87",
        "name": "iPhone Model 87",
        "date": "2023-03-03",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_desert_titanium_pdp_image_position_1__ce-ww_1.webp"
    },
    {
        "userId": 88,
        "id": "iphone-id-88",
        "name": "iPhone Model 88",
        "date": "2023-04-04",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_desert_titanium_pdp_image_position_1__ce-ww_1.webp"
    },
    {
        "userId": 89,
        "id": "iphone-id-89",
        "name": "iPhone Model 89",
        "date": "2023-05-05",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-black-select-2020_3.webp"
    },
    {
        "userId": 90,
        "id": "iphone-id-90",
        "name": "iPhone Model 90",
        "date": "2023-06-06",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-blue-select-2020_3_1_1.jpg"
    },
    {
        "userId": 91,
        "id": "iphone-id-91",
        "name": "iPhone Model 91",
        "date": "2023-07-07",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_desert_titanium_pdp_image_position_1__ce-ww_1.webp"
    },
    {
        "userId": 92,
        "id": "iphone-id-92",
        "name": "iPhone Model 92",
        "date": "2023-08-08",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-blue-select-2020_3_1_1.jpg"
    },
    {
        "userId": 93,
        "id": "iphone-id-93",
        "name": "iPhone Model 93",
        "date": "2023-09-09",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-blue-select-2020_3_1_1.jpg"
    },
    {
        "userId": 130,
        "id": "iphone-id-130",
        "name": "iPhone Model 130",
        "date": "2023-10-18",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_max_desert_titanium_pdp_image_position_1__ce-ww_2.webp"
    },
    {
        "userId": 131,
        "id": "iphone-id-131",
        "name": "iPhone Model 131",
        "date": "2023-11-19",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_black_pdp_image_position_1__ce-ww1725952011.webp"
    },
    {
        "userId": 132,
        "id": "iphone-id-132",
        "name": "iPhone Model 132",
        "date": "2023-12-20",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-blue-select-2020_3_1_1.jpg"
    },
    {
        "userId": 133,
        "id": "iphone-id-133",
        "name": "iPhone Model 133",
        "date": "2023-01-21",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-black-select-2020_3.webp"
    },
    {
        "userId": 134,
        "id": "iphone-id-134",
        "name": "iPhone Model 134",
        "date": "2023-02-22",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_15_plus_black_pdp_image_position-1__ww-en.jpg"
    },
    {
        "userId": 135,
        "id": "iphone-id-135",
        "name": "iPhone Model 135",
        "date": "2023-03-23",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/w/w/wwen_iphone14_q422_productred_pdp_image_position-1a_3.jpg"
    },
    {
        "userId": 136,
        "id": "iphone-id-136",
        "name": "iPhone Model 136",
        "date": "2023-04-24",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_desert_titanium_pdp_image_position_1__ce-ww_1.webp"
    },
    {
        "userId": 137,
        "id": "iphone-id-137",
        "name": "iPhone Model 137",
        "date": "2023-05-25",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/468x468/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_15_plus_pink_pdp_image_position-1__ww-en.jpg"
    },
    {
        "userId": 138,
        "id": "iphone-id-138",
        "name": "iPhone Model 138",
        "date": "2023-06-26",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_black_pdp_image_position_1__ce-ww1725952011.webp"
    },
    {
        "userId": 139,
        "id": "iphone-id-139",
        "name": "iPhone Model 139",
        "date": "2023-07-27",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-blue-select-2020_3_1_1.jpg"
    },
    {
        "userId": 140,
        "id": "iphone-id-140",
        "name": "iPhone Model 140",
        "date": "2023-08-28",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/710x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_black_titanium_pdp_image_position_5__ce-ww_2.webp"
    },
    {
        "userId": 141,
        "id": "iphone-id-141",
        "name": "iPhone Model 141",
        "date": "2023-09-01",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_15_plus_black_pdp_image_position-1__ww-en.jpg"
    },
    {
        "userId": 142,
        "id": "iphone-id-142",
        "name": "iPhone Model 142",
        "date": "2023-10-02",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/w/w/wwen_iphone14_q422_productred_pdp_image_position-1a_3.jpg"
    },
    {
        "userId": 143,
        "id": "iphone-id-143",
        "name": "iPhone Model 143",
        "date": "2023-11-03",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_desert_titanium_pdp_image_position_1__ce-ww_1.webp"
    },
    {
        "userId": 144,
        "id": "iphone-id-144",
        "name": "iPhone Model 144",
        "date": "2023-12-04",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_max_desert_titanium_pdp_image_position_1__ce-ww_2.webp"
    },
    {
        "userId": 145,
        "id": "iphone-id-145",
        "name": "iPhone Model 145",
        "date": "2023-01-05",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_black_pdp_image_position_1__ce-ww1725952011.webp"
    },
    {
        "userId": 146,
        "id": "iphone-id-146",
        "name": "iPhone Model 146",
        "date": "2023-02-06",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-blue-select-2020_3_1_1.jpg"
    },
    {
        "userId": 147,
        "id": "iphone-id-147",
        "name": "iPhone Model 147",
        "date": "2023-03-07",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-black-select-2020_3.webp"
    },
    {
        "userId": 148,
        "id": "iphone-id-148",
        "name": "iPhone Model 148",
        "date": "2023-04-08",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_15_plus_black_pdp_image_position-1__ww-en.jpg"
    },
    {
        "userId": 149,
        "id": "iphone-id-149",
        "name": "iPhone Model 149",
        "date": "2023-05-09",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/w/w/wwen_iphone14_q422_productred_pdp_image_position-1a_3.jpg"
    },
    {
        "userId": 150,
        "id": "iphone-id-150",
        "name": "iPhone Model 150",
        "date": "2023-06-10",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_desert_titanium_pdp_image_position_1__ce-ww_1.webp"
    },
    {
        "userId": 151,
        "id": "iphone-id-151",
        "name": "iPhone Model 151",
        "date": "2023-07-11",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_max_desert_titanium_pdp_image_position_1__ce-ww_2.webp"
    },
    {
        "userId": 152,
        "id": "iphone-id-152",
        "name": "iPhone Model 152",
        "date": "2023-08-12",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_black_pdp_image_position_1__ce-ww1725952011.webp"
    },
    {
        "userId": 153,
        "id": "iphone-id-153",
        "name": "iPhone Model 153",
        "date": "2023-09-13",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-blue-select-2020_3_1_1.jpg"
    },
    {
        "userId": 154,
        "id": "iphone-id-154",
        "name": "iPhone Model 154",
        "date": "2023-10-14",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-black-select-2020_3.webp"
    },
    {
        "userId": 155,
        "id": "iphone-id-155",
        "name": "iPhone Model 155",
        "date": "2023-11-15",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_15_plus_black_pdp_image_position-1__ww-en.jpg"
    },
    {
        "userId": 156,
        "id": "iphone-id-156",
        "name": "iPhone Model 156",
        "date": "2023-12-16",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/w/w/wwen_iphone14_q422_productred_pdp_image_position-1a_3.jpg"
    },
    {
        "userId": 157,
        "id": "iphone-id-157",
        "name": "iPhone Model 157",
        "date": "2023-01-17",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_desert_titanium_pdp_image_position_1__ce-ww_1.webp"
    },
    {
        "userId": 158,
        "id": "iphone-id-158",
        "name": "iPhone Model 158",
        "date": "2023-02-18",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_max_desert_titanium_pdp_image_position_1__ce-ww_2.webp"
    },
    {
        "userId": 159,
        "id": "iphone-id-159",
        "name": "iPhone Model 159",
        "date": "2023-03-19",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_black_pdp_image_position_1__ce-ww1725952011.webp"
    },
    {
        "userId": 160,
        "id": "iphone-id-160",
        "name": "iPhone Model 160",
        "date": "2023-04-20",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-blue-select-2020_3_1_1.jpg"
    },
    {
        "userId": 161,
        "id": "iphone-id-161",
        "name": "iPhone Model 161",
        "date": "2023-05-21",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-black-select-2020_3.webp"
    },
    {
        "userId": 162,
        "id": "iphone-id-162",
        "name": "iPhone Model 162",
        "date": "2023-06-22",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_15_plus_black_pdp_image_position-1__ww-en.jpg"
    },
    {
        "userId": 163,
        "id": "iphone-id-163",
        "name": "iPhone Model 163",
        "date": "2023-07-23",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/w/w/wwen_iphone14_q422_productred_pdp_image_position-1a_3.jpg"
    },
    {
        "userId": 164,
        "id": "iphone-id-164",
        "name": "iPhone Model 164",
        "date": "2023-08-24",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_desert_titanium_pdp_image_position_1__ce-ww_1.webp"
    },
    {
        "userId": 165,
        "id": "iphone-id-165",
        "name": "iPhone Model 165",
        "date": "2023-09-25",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_max_desert_titanium_pdp_image_position_1__ce-ww_2.webp"
    },
    {
        "userId": 166,
        "id": "iphone-id-166",
        "name": "iPhone Model 166",
        "date": "2023-10-26",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_black_pdp_image_position_1__ce-ww1725952011.webp"
    },
    {
        "userId": 167,
        "id": "iphone-id-167",
        "name": "iPhone Model 167",
        "date": "2023-11-27",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-blue-select-2020_3_1_1.jpg"
    },
    {
        "userId": 168,
        "id": "iphone-id-168",
        "name": "iPhone Model 168",
        "date": "2023-12-28",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-black-select-2020_3.webp"
    },
    {
        "userId": 169,
        "id": "iphone-id-169",
        "name": "iPhone Model 169",
        "date": "2023-01-01",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_15_plus_black_pdp_image_position-1__ww-en.jpg"
    },
    {
        "userId": 170,
        "id": "iphone-id-170",
        "name": "iPhone Model 170",
        "date": "2023-02-02",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/w/w/wwen_iphone14_q422_productred_pdp_image_position-1a_3.jpg"
    },
    {
        "userId": 171,
        "id": "iphone-id-171",
        "name": "iPhone Model 171",
        "date": "2023-03-03",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_desert_titanium_pdp_image_position_1__ce-ww_1.webp"
    },
    {
        "userId": 172,
        "id": "iphone-id-172",
        "name": "iPhone Model 172",
        "date": "2023-04-04",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_max_desert_titanium_pdp_image_position_1__ce-ww_2.webp"
    },
    {
        "userId": 173,
        "id": "iphone-id-173",
        "name": "iPhone Model 173",
        "date": "2023-05-05",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_black_pdp_image_position_1__ce-ww1725952011.webp"
    },
    {
        "userId": 174,
        "id": "iphone-id-174",
        "name": "iPhone Model 174",
        "date": "2023-06-06",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-blue-select-2020_3_1_1.jpg"
    },
    {
        "userId": 175,
        "id": "iphone-id-175",
        "name": "iPhone Model 175",
        "date": "2023-07-07",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-black-select-2020_3.webp"
    },
    {
        "userId": 176,
        "id": "iphone-id-176",
        "name": "iPhone Model 176",
        "date": "2023-08-08",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_15_plus_black_pdp_image_position-1__ww-en.jpg"
    },
    {
        "userId": 177,
        "id": "iphone-id-177",
        "name": "iPhone Model 177",
        "date": "2023-09-09",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/w/w/wwen_iphone14_q422_productred_pdp_image_position-1a_3.jpg"
    },
    {
        "userId": 178,
        "id": "iphone-id-178",
        "name": "iPhone Model 178",
        "date": "2023-10-10",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_desert_titanium_pdp_image_position_1__ce-ww_1.webp"
    },
    {
        "userId": 179,
        "id": "iphone-id-179",
        "name": "iPhone Model 179",
        "date": "2023-11-11",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_max_desert_titanium_pdp_image_position_1__ce-ww_2.webp"
    },
    {
        "userId": 180,
        "id": "iphone-id-180",
        "name": "iPhone Model 180",
        "date": "2023-12-12",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_black_pdp_image_position_1__ce-ww1725952011.webp"
    },
    {
        "userId": 181,
        "id": "iphone-id-181",
        "name": "iPhone Model 181",
        "date": "2023-01-13",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-blue-select-2020_3_1_1.jpg"
    },
    {
        "userId": 182,
        "id": "iphone-id-182",
        "name": "iPhone Model 182",
        "date": "2023-02-14",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-black-select-2020_3.webp"
    },
    {
        "userId": 183,
        "id": "iphone-id-183",
        "name": "iPhone Model 183",
        "date": "2023-03-15",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_15_plus_black_pdp_image_position-1__ww-en.jpg"
    },
    {
        "userId": 184,
        "id": "iphone-id-184",
        "name": "iPhone Model 184",
        "date": "2023-04-16",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/w/w/wwen_iphone14_q422_productred_pdp_image_position-1a_3.jpg"
    },
    {
        "userId": 185,
        "id": "iphone-id-185",
        "name": "iPhone Model 185",
        "date": "2023-05-17",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_desert_titanium_pdp_image_position_1__ce-ww_1.webp"
    },
    {
        "userId": 186,
        "id": "iphone-id-186",
        "name": "iPhone Model 186",
        "date": "2023-06-18",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_max_desert_titanium_pdp_image_position_1__ce-ww_2.webp"
    },
    {
        "userId": 187,
        "id": "iphone-id-187",
        "name": "iPhone Model 187",
        "date": "2023-07-19",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_black_pdp_image_position_1__ce-ww1725952011.webp"
    },
    {
        "userId": 188,
        "id": "iphone-id-188",
        "name": "iPhone Model 188",
        "date": "2023-08-20",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-blue-select-2020_3_1_1.jpg"
    },
    {
        "userId": 189,
        "id": "iphone-id-189",
        "name": "iPhone Model 189",
        "date": "2023-09-21",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-black-select-2020_3.webp"
    },
    {
        "userId": 190,
        "id": "iphone-id-190",
        "name": "iPhone Model 190",
        "date": "2023-10-22",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_15_plus_black_pdp_image_position-1__ww-en.jpg"
    },
    {
        "userId": 191,
        "id": "iphone-id-191",
        "name": "iPhone Model 191",
        "date": "2023-11-23",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/w/w/wwen_iphone14_q422_productred_pdp_image_position-1a_3.jpg"
    },
    {
        "userId": 192,
        "id": "iphone-id-192",
        "name": "iPhone Model 192",
        "date": "2023-12-24",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_desert_titanium_pdp_image_position_1__ce-ww_1.webp"
    },
    {
        "userId": 193,
        "id": "iphone-id-193",
        "name": "iPhone Model 193",
        "date": "2023-01-25",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_max_desert_titanium_pdp_image_position_1__ce-ww_2.webp"
    },
    {
        "userId": 194,
        "id": "iphone-id-194",
        "name": "iPhone Model 194",
        "date": "2023-02-26",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_black_pdp_image_position_1__ce-ww1725952011.webp"
    },
    {
        "userId": 195,
        "id": "iphone-id-195",
        "name": "iPhone Model 195",
        "date": "2023-03-27",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_desert_titanium_pdp_image_position_1__ce-ww_1.webp"
    },
    {
        "userId": 196,
        "id": "iphone-id-196",
        "name": "iPhone Model 196",
        "date": "2023-04-28",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_max_desert_titanium_pdp_image_position_1__ce-ww_2.webp"
    },
    {
        "userId": 197,
        "id": "iphone-id-197",
        "name": "iPhone Model 197",
        "date": "2023-05-01",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_black_pdp_image_position_1__ce-ww1725952011.webp"
    },
    {
        "userId": 198,
        "id": "iphone-id-198",
        "name": "iPhone Model 198",
        "date": "2023-06-02",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-blue-select-2020_3_1_1.jpg"
    },
    {
        "userId": 199,
        "id": "iphone-id-199",
        "name": "iPhone Model 199",
        "date": "2023-07-03",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone-12-mini-black-select-2020_3.webp"
    },
    {
        "userId": 200,
        "id": "iphone-id-200",
        "name": "iPhone Model 200",
        "date": "2023-08-04",
        "img": "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_15_plus_black_pdp_image_position-1__ww-en.jpg"
    }
];
}}),
"[project]/features/purchases/components/PurchasesList.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, d: __dirname } = __turbopack_context__;
{
/*
"use client"

// components/PurchasesList.tsx
import React, {useEffect, useState} from "react";
import Image from "next/image";
import { getAllUsersPurchases } from "@/services/api/usersService";
import { Purchase } from "@/shared/types/user";
import {usePurchasesQuery} from "@/shared/hooks/usePurchasesQuery";

// Ця компонента – серверна, тому вона може бути async
export default function PurchasesList() {
    // Отримуємо дані прямо на сервері
    const purchases = usePurchasesQuery();
    //const purchases: Purchase[] = await getAllUsersPurchases();
    const [isMounted, setIsMounted] = useState(false);


    useEffect(() => {
        setIsMounted(true);
    }, []);

    if (!isMounted) {
        return null;
    }
    return (
        <div className="grid grid-cols-5 gap-4">
            {purchases.data?.map((purchase) => (
                <div key={purchase.id} className="border p-2">
                    <Image
                        alt={purchase.name}
                        src={purchase.img  || ""} // API повинно повертати img як URL
                        width={123}
                        height={124}

                        loading={"eager"}
                    />
                    <div className="mt-2 text-sm">
                        <p className="font-semibold">{purchase.name}</p>
                        <p className="text-gray-500">User ID: {purchase.userId}</p>
                        <p className="text-gray-400 text-xs">{purchase.date}</p>
                    </div>
                </div>
            ))}
        </div>
    );
}
*/ /*


// purchases/components/PurchasesList.tsx (СЕРВЕРНА КОМПОНЕНТА, без use client!)
import React from "react";
import Image from "next/image";
import { getAllUsersPurchases } from "@/services/api/usersService";
import { Purchase } from "@/shared/types/user";

export default async function PurchasesList() {
    const purchases: Purchase[] = await getAllUsersPurchases();

    return (
        <div className="grid grid-cols-5 gap-4">
            {purchases.map((purchase) => (
                <div key={purchase.id} className="border p-2">
                    <Image
                        alt={purchase.name}
                        src={purchase.img || ""}
                        width={123}
                        height={124}
                        // У Next Image в 13-й версії лентиве завантаження і так за замовчуванням,
                        // але якщо хочете явно, то можна вказати loading="lazy"
                        loading="lazy"
                    />
                    <div className="mt-2 text-sm">
                        <p className="font-semibold">{purchase.name}</p>
                        <p className="text-gray-500">User ID: {purchase.userId}</p>
                        <p className="text-gray-400 text-xs">{purchase.date}</p>
                    </div>
                </div>
            ))}
        </div>
    );
}
*/ __turbopack_context__.s({
    "default": (()=>PurchasesList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$shared$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/shared/constants.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
function PurchasesList() {
    // const { data: purchases, isLoading } = usePurchasesQuery();
    // if (isLoading) return <div>Loading...</div>;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "grid grid-cols-5 gap-4",
        children: __TURBOPACK__imported__module__$5b$project$5d2f$shared$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["purchases"]?.map((purchase)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "border p-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        alt: purchase.name,
                        src: purchase.img || "",
                        width: 123,
                        height: 124,
                        loading: "lazy"
                    }, void 0, false, {
                        fileName: "[project]/features/purchases/components/PurchasesList.tsx",
                        lineNumber: 101,
                        columnNumber: 21
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-2 text-sm",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "font-semibold",
                                children: purchase.name
                            }, void 0, false, {
                                fileName: "[project]/features/purchases/components/PurchasesList.tsx",
                                lineNumber: 109,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-gray-500",
                                children: [
                                    "User ID: ",
                                    purchase.userId
                                ]
                            }, void 0, true, {
                                fileName: "[project]/features/purchases/components/PurchasesList.tsx",
                                lineNumber: 110,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-gray-400 text-xs",
                                children: purchase.date
                            }, void 0, false, {
                                fileName: "[project]/features/purchases/components/PurchasesList.tsx",
                                lineNumber: 111,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/purchases/components/PurchasesList.tsx",
                        lineNumber: 108,
                        columnNumber: 21
                    }, this)
                ]
            }, purchase.id, true, {
                fileName: "[project]/features/purchases/components/PurchasesList.tsx",
                lineNumber: 100,
                columnNumber: 17
            }, this))
    }, void 0, false, {
        fileName: "[project]/features/purchases/components/PurchasesList.tsx",
        lineNumber: 98,
        columnNumber: 9
    }, this);
}
}}),
"[project]/features/users/components/clients/UsersListClientVirtualized.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, d: __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$window$2f$dist$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-window/dist/index.esm.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$users$2f$components$2f$UserCard$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/users/components/UserCard.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$purchases$2f$components$2f$PurchasesModal$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/purchases/components/PurchasesModal.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$features$2f$purchases$2f$components$2f$PurchasesList$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/features/purchases/components/PurchasesList.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
const fetchUsers = async ()=>{
    const res = await fetch("http://localhost:3001/api/users");
    if (!res.ok) throw new Error("Failed to fetch users");
    return res.json();
};
const MemoizedUserCard = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["memo"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$users$2f$components$2f$UserCard$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]);
const COLUMN_COUNT = 5;
const CARD_WIDTH = 335;
const CARD_HEIGHT = 480;
const VirtualizedUsersGrid = ()=>{
    const { data: users = [], isLoading, error } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQuery"])({
        queryKey: [
            "users"
        ],
        queryFn: fetchUsers
    });
    const [sortBy, setSortBy] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("age");
    const [search, setSearch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const handleUsersPurchasesClick = ()=>{
        router.push("/users-purchases");
    };
    const handleSearchChange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])((e)=>{
        setSearch(e.target.value);
    }, []);
    const sortedUsers = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        return [
            ...users
        ].filter((user)=>user.firstName.toLowerCase().includes(search.toLowerCase())).sort((a, b)=>sortBy === "age" ? a.age - b.age : a.firstName.localeCompare(b.firstName));
    }, [
        users,
        search,
        sortBy
    ]);
    const handleUserClick = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])((id)=>{
        router.replace(`/${id}`);
    }, []);
    if (isLoading) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
        children: "Loading..."
    }, void 0, false, {
        fileName: "[project]/features/users/components/clients/UsersListClientVirtualized.tsx",
        lineNumber: 40,
        columnNumber: 27
    }, this);
    if (error) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
        children: [
            "Error: ",
            error.message
        ]
    }, void 0, true, {
        fileName: "[project]/features/users/components/clients/UsersListClientVirtualized.tsx",
        lineNumber: 41,
        columnNumber: 23
    }, this);
    const rowCount = Math.ceil(sortedUsers.length / COLUMN_COUNT);
    const Cell = ({ columnIndex, rowIndex, style })=>{
        const index = rowIndex * COLUMN_COUNT + columnIndex;
        const user = sortedUsers[index];
        if (!user) return null;
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            style: style,
            className: "p-2",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(MemoizedUserCard, {
                user: user,
                onClick: handleUserClick
            }, void 0, false, {
                fileName: "[project]/features/users/components/clients/UsersListClientVirtualized.tsx",
                lineNumber: 49,
                columnNumber: 17
            }, this)
        }, void 0, false, {
            fileName: "[project]/features/users/components/clients/UsersListClientVirtualized.tsx",
            lineNumber: 48,
            columnNumber: 13
        }, this);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "p-3 bg-blue-200",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: handleUsersPurchasesClick,
                className: "my-3 text-purple underline cursor-pointer",
                children: "Users purchases"
            }, void 0, false, {
                fileName: "[project]/features/users/components/clients/UsersListClientVirtualized.tsx",
                lineNumber: 58,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                type: "text",
                placeholder: "search for name",
                value: search,
                onChange: handleSearchChange,
                className: "p-2 mb-4 w-full border rounded"
            }, void 0, false, {
                fileName: "[project]/features/users/components/clients/UsersListClientVirtualized.tsx",
                lineNumber: 61,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-5",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>setSortBy(sortBy === "age" ? "firstName" : "age"),
                        className: "mb-4 p-2 bg-blue-500 text-white rounded",
                        children: [
                            "Sort by ",
                            sortBy === "age" ? "name" : "age"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/features/users/components/clients/UsersListClientVirtualized.tsx",
                        lineNumber: 69,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$purchases$2f$components$2f$PurchasesModal$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/features/users/components/clients/UsersListClientVirtualized.tsx",
                            lineNumber: 76,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/features/users/components/clients/UsersListClientVirtualized.tsx",
                        lineNumber: 75,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/features/users/components/clients/UsersListClientVirtualized.tsx",
                lineNumber: 68,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$window$2f$dist$2f$index$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FixedSizeGrid"], {
                columnCount: COLUMN_COUNT,
                columnWidth: CARD_WIDTH - 10,
                height: 794,
                rowCount: rowCount,
                rowHeight: CARD_HEIGHT,
                width: CARD_WIDTH * COLUMN_COUNT,
                children: Cell
            }, void 0, false, {
                fileName: "[project]/features/users/components/clients/UsersListClientVirtualized.tsx",
                lineNumber: 79,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-5",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$features$2f$purchases$2f$components$2f$PurchasesList$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/features/users/components/clients/UsersListClientVirtualized.tsx",
                    lineNumber: 90,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/features/users/components/clients/UsersListClientVirtualized.tsx",
                lineNumber: 89,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/features/users/components/clients/UsersListClientVirtualized.tsx",
        lineNumber: 57,
        columnNumber: 9
    }, this);
};
const __TURBOPACK__default__export__ = VirtualizedUsersGrid;
}}),

};

//# sourceMappingURL=%5Broot%20of%20the%20server%5D__19dd9c93._.js.map