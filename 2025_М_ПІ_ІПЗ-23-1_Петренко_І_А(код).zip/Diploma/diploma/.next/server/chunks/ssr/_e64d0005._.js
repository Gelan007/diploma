module.exports = {

"[project]/services/api/usersService.ts [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, d: __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "getAllUsersPurchases": (()=>getAllUsersPurchases),
    "getUsers": (()=>getUsers)
});
const getUsers = async ()=>{
    const res = await fetch("http://localhost:3001/api/users");
    if (!res.ok) throw new Error("Failed to fetch users");
    return res.json();
};
const getAllUsersPurchases = async ()=>{
    const res = await fetch("http://localhost:3001/api/users/purchases");
    if (!res.ok) throw new Error("Failed to fetch purchases");
    return res.json();
};
}}),
"[project]/shared/hooks/usePurchasesQuery.ts [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, d: __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "usePurchasesQuery": (()=>usePurchasesQuery)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$api$2f$usersService$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/services/api/usersService.ts [app-ssr] (ecmascript)");
;
;
const images = [
    "/assets/images/iphone1.png",
    "/assets/images/iphone2.png",
    "/assets/images/iphone3.png",
    "/assets/images/iphone4.png",
    "/assets/images/iphone5.png",
    "/assets/images/iphone6.png",
    "/assets/images/iphone7.png"
];
function usePurchasesQuery() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQuery"])({
        queryKey: [
            "purchases"
        ],
        queryFn: async ()=>{
            const data = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$api$2f$usersService$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getAllUsersPurchases"])();
            return data.map((item, index)=>({
                    ...item,
                    img: images[index % images.length]
                }));
        }
    });
}
}}),
"[project]/app/users-purchases/page.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, d: __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$shared$2f$hooks$2f$usePurchasesQuery$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/shared/hooks/usePurchasesQuery.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-ssr] (ecmascript)");
"use client";
;
;
;
;
/*// Приклад масиву зображень. Реальні дані можуть завантажуватися із API або бути статичними.
const images: ImageData[] = [
    { id: 1, src: "/images/image1.jpg", alt: "Зображення 1" },
    { id: 2, src: "/images/image2.jpg", alt: "Зображення 2" },
    { id: 3, src: "/images/image3.jpg", alt: "Зображення 3" },
    { id: 4, src: "/images/image4.jpg", alt: "Зображення 4" },
    { id: 5, src: "/images/image5.jpg", alt: "Зображення 5" },
    // Додайте більше зображень за потреби
];*/ const UsersOrdersPage = ()=>{
    const purchases = (0, __TURBOPACK__imported__module__$5b$project$5d2f$shared$2f$hooks$2f$usePurchasesQuery$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["usePurchasesQuery"])();
    console.log(purchases);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "p-3",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                className: "text-2xl font-bold mb-4",
                children: "Users last purchases"
            }, void 0, false, {
                fileName: "[project]/app/users-purchases/page.tsx",
                lineNumber: 28,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-3 gap-4",
                children: purchases.data?.map((purchase, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "border p-2",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            alt: "Iphone",
                            src: "https://i.allo.ua/media/catalog/product/cache/1/image/620x600/602f0fa2c1f0d1ba5e241f914e856ff9/i/p/iphone_16_pro_max_desert_titanium_pdp_image_position_1__ce-ww_2.webp",
                            width: 123,
                            height: 124
                        }, void 0, false, {
                            fileName: "[project]/app/users-purchases/page.tsx",
                            lineNumber: 44,
                            columnNumber: 25
                        }, this)
                    }, index, false, {
                        fileName: "[project]/app/users-purchases/page.tsx",
                        lineNumber: 37,
                        columnNumber: 21
                    }, this))
            }, void 0, false, {
                fileName: "[project]/app/users-purchases/page.tsx",
                lineNumber: 35,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/users-purchases/page.tsx",
        lineNumber: 27,
        columnNumber: 9
    }, this);
};
const __TURBOPACK__default__export__ = UsersOrdersPage;
}}),

};

//# sourceMappingURL=_e64d0005._.js.map