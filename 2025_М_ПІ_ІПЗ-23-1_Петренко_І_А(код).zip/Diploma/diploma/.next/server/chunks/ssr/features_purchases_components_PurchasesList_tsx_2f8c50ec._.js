module.exports = {

"[project]/features/purchases/components/PurchasesList.tsx [app-rsc] (ecmascript, next/dynamic entry, async loader)": ((__turbopack_context__) => {

var { g: global, d: __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/_d4927f93._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/features/purchases/components/PurchasesList.tsx [app-rsc] (ecmascript, next/dynamic entry)");
    });
});
}}),

};