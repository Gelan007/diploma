module.exports = {

"[project]/.next-internal/server/app/api/users/route/actions.js [app-rsc] (server actions loader, ecmascript)": (function(__turbopack_context__) {

var { g: global, d: __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),
"[externals]/next/dist/compiled/next-server/app-route.runtime.dev.js [external] (next/dist/compiled/next-server/app-route.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, d: __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)": (function(__turbopack_context__) {

var { g: global, d: __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/next-server/app-page.runtime.dev.js [external] (next/dist/compiled/next-server/app-page.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, d: __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, d: __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, d: __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[project]/app/api/users/route.ts [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, d: __dirname } = __turbopack_context__;
{
// import {connectToDB} from "@utils/database";
// import Expense from "@models/expense";
// import {IExpense} from "@interfaces/expense";
// import {NextResponse} from "@node_modules/next/dist/server/web/spec-extension/response";
// export const POST = async (req: Request , res: Response) => {
//     try {
//         const { description, amount, date }: IExpense = await req.json();
//
//         await connectToDB();
//
//         const newExpense = new Expense({
//             description,
//             amount,
//             date: new Date(date)
//         });
//
//         await newExpense.save();
//
//         return new Response(JSON.stringify(newExpense), { status: 201 });
//     } catch (err) {
//         return new Response("Failed to create a new expense", { status: 500 });
//     }
//
// }
//
// export const GET = async (req: Request , res: Response) => {
//     try {
//         await connectToDB();
//
//         const expenses = await Expense.find({});
//         return new Response(JSON.stringify(expenses), {status: 200})
//     } catch(err) {
//         return new Response("Failed to fetch all expenses", {status: 500});
//     }
// }
__turbopack_context__.s({
    "getUsers": (()=>getUsers)
});
const getUsers = async (req, res)=>{
    try {
        const users = [];
        for(let i = 6; i <= 100; i++){
            users.push({
                id: i,
                firstName: `User${i}`,
                lastName: `LastName${i}`,
                age: Math.floor(Math.random() * 50) + 18,
                email: `user${i}@example.com`,
                phone: `+1-555-01${i < 10 ? '0' : ''}${i}`,
                country: [
                    "USA",
                    "Canada",
                    "UK",
                    "Australia",
                    "Germany"
                ][Math.floor(Math.random() * 5)],
                city: [
                    "New York",
                    "Toronto",
                    "London",
                    "Sydney",
                    "Berlin"
                ][Math.floor(Math.random() * 5)]
            });
        }
        console.log(users);
    //const users =
    //return new Response(JSON.stringify(expenses), {status: 200})
    } catch (err) {
        return new Response("Failed to fetch all expenses", {
            status: 500
        });
    }
};
}}),

};

//# sourceMappingURL=%5Broot%20of%20the%20server%5D__f9b015e6._.js.map