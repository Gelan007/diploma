import { createSlice, PayloadAction } from '@reduxjs/toolkit';

interface User {
    id: string;
    name: string;
}

interface UsersState {
    list: User[];
}

const initialState: UsersState = {
    list: [],
};

const usersSlice = createSlice({
    name: 'users',
    initialState,
    reducers: {

    },
});

export const {  } = usersSlice.actions;
export default usersSlice.reducer;