import express from "express";
import expenseRouter from "./expenseRouter";
import userRoute from "./userRoute";
const router = express.Router();

router.use("/expenses", expenseRouter)
router.use("/users", userRoute)
router.get("/", (req: express.Request, res: express.Response) => {
    res.status(200).json({body: "hello world"});
});
export default router;