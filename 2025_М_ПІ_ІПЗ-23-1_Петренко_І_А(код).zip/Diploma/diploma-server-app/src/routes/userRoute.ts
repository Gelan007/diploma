import express from "express"
import {getAllUsers, getAllUsersPurchases} from "../controllers/userController";


const router = express.Router();

router.get("/", getAllUsers)
router.get("/purchases", getAllUsersPurchases)
export default router;