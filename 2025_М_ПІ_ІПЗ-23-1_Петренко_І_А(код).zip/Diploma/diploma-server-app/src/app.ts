import express from 'express';
import dotenv from 'dotenv';
import connectDB from './config/db';
import {errorHandler} from "./middlewares/errorHandler";
import router from "../src/routes/indexRoutes"
import cors from "cors";
import {logger} from "./utils/appHelper";

dotenv.config();
const app = express();

app.use(cors({
    origin: "*",
    methods: "*",
    allowedHeaders: "*"
}))
app.use(express.json());
app.use('/api', logger, router)

connectDB();
app.use(errorHandler)


const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
