import ExpenseService from "../services/expenseService";
import {ExpenseDTO} from "../dtos/expense.dto";
import {NextFunction, Request, Response} from 'express';
import UserService from "../services/userService";


export const getAllUsers = async (req: Request, res: Response, next: NextFunction) => {
    try {
        const users = UserService.getUsers();
        res.json(users);
    } catch (err: any) {
        res.status(400).json({ error: err.message });
    }
}

export const getAllUsersPurchases = async (req: Request, res: Response, next: NextFunction) => {
    try {
        const purchases = UserService.getPurchases();
        res.json(purchases);
    } catch (err: any) {
        res.status(400).json({ error: err.message });
    }
}