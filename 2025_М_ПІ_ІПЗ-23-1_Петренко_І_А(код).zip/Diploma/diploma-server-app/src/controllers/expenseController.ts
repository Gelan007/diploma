import ExpenseService from "../services/expenseService";
import {ExpenseDTO} from "../dtos/expense.dto";
import {NextFunction, Request, Response} from 'express';


export const createExpense = async (req: Request, res: Response, next: NextFunction) => {
    try {
        const {description, amount} = req.body;

        if (!description || !amount) {
            return res.status(400).json({ error: "Description and amount are required" });
        }
        const expense = await ExpenseService.createExpense(req.body)
        res.json(expense);
    } catch (err: any) {
        res.status(400).json({ error: err.message });
    }
}