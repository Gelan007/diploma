import Expense, {IExpense} from "../models/Expense";
import {ExpenseDTO} from "../dtos/expense.dto";

class ExpenseRepository {
    async createExpense(data: ExpenseDTO): Promise<IExpense> {
        return await Expense.create(data);
    }

    async findAll(): Promise<IExpense[]> {
        return await Expense.find();
    }

    async findOneById(id: string): Promise<IExpense | null> {
        return await Expense.findById(id)
    }
}

export default new ExpenseRepository();