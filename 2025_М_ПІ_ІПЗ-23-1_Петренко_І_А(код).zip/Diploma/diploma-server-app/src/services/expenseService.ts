import {IExpense} from "../models/Expense";
import {ExpenseDTO} from "../dtos/expense.dto";
import expenseRepository from "../repositories/expenseRepository";

class ExpenseService {
    async createExpense(expense: ExpenseDTO): Promise<IExpense> {
        if(expense.description?.length > 300) {
            throw new Error ("Expense description should be less than 300");
        }

        return await expenseRepository.createExpense(expense)
    }
}

export default new ExpenseService();