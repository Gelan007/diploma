import {IExpense} from "../models/Expense";
import {ExpenseDTO} from "../dtos/expense.dto";
import expenseRepository from "../repositories/expenseRepository";
import {Purchase, UserDTO} from "../dtos/user.dto";
import {users} from "../constants/users";
import {purchases} from "../constants/purchases";


class UserService {
     getUsers(): UserDTO[] {
        return users;
    }
    getPurchases(): Purchase[] {
        return purchases;
    }
}

export default new UserService();