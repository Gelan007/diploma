export interface UserDTO {
    id: number;
    email: string;
    age: number;
    firstName: string;
    lastName: string;
    phone: string;
    country: string;
    city: string;
}


export interface Purchase {
    id: string;
    name: string;
    date: string;
}

