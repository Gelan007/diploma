export interface ExpenseDTO {
    description: string;
    amount: number;
}

